#!/bin/bash
set -e

# Main installation script
echo "Starting server setup..."

# Get domain and email configuration
./scripts/setup.sh

# Execute scripts in order
./scripts/00-init.sh
./scripts/01-nodejs.sh
./scripts/02-nginx.sh
./scripts/03-postgres.sh
./scripts/04-redis.sh
./scripts/05-ssl-domain.sh
./scripts/database/n8n-db-config.sh
./scripts/06-n8n.sh
./scripts/07-backup.sh
./scripts/08-monitoring.sh

echo "Installation completed successfully!"
echo "n8n is available at https://${DOMAIN}"
echo "Please save your credentials from config/settings.env"