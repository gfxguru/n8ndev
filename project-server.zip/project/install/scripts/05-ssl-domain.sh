#!/bin/bash
set -e

source ./config/settings.env

echo "Setting up SSL and domain configuration..."

# Execute SSL setup scripts
./scripts/ssl/certbot.sh
./scripts/ssl/nginx-ssl.sh

# Execute domain configuration scripts
./scripts/domain/nginx-domain.sh
./scripts/domain/n8n-domain.sh

echo "SSL and domain configuration completed successfully!"