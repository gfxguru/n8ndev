#!/bin/bash
set -e

source ./config/settings.env

setup_redis() {
    echo "Setting up Redis..."
    
    # Install Redis
    sudo apt-get install -y redis-server

    # Configure Redis
    sudo tee /etc/redis/redis.conf << EOF
bind 127.0.0.1
port ${REDIS_PORT}
maxmemory 256mb
maxmemory-policy allkeys-lru
EOF

    # Enable and start Redis
    sudo systemctl enable redis-server
    sudo systemctl restart redis-server
}

setup_redis