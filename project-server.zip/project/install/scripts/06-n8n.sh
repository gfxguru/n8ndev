#!/bin/bash
set -e

source ./config/settings.env

setup_n8n() {
    echo "Setting up n8n..."
    
    # Install n8n globally
    sudo npm install -g n8n

    # Create n8n system user
    sudo useradd -r -s /bin/false n8n

    # Create required directories
    sudo mkdir -p ${N8N_DIR}/{config,logs,data}
    
    # Combine environment configurations
    sudo tee ${N8N_DIR}/config/.env << EOF
# Import configurations
source ${N8N_DIR}/config/domain.env
source ${N8N_DIR}/config/database.env

# Additional Settings
N8N_USER_FOLDER="${N8N_DIR}/data"
N8N_LOG_LEVEL="info"
N8N_LOG_OUTPUT="${N8N_DIR}/logs/n8n.log"

EXECUTIONS_DATA_PRUNE=true
EXECUTIONS_DATA_MAX_AGE=168
EXECUTIONS_DATA_PRUNE_TIMEOUT=7200

GENERIC_TIMEZONE="UTC"
EOF

    # Create systemd service
    sudo tee /etc/systemd/system/n8n.service << EOF
[Unit]
Description=n8n Workflow Automation
After=network.target postgresql.service redis-server.service

[Service]
Type=simple
User=n8n
EnvironmentFile=${N8N_DIR}/config/.env
ExecStart=/usr/bin/n8n start
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    # Set permissions
    sudo chown -R n8n:n8n ${N8N_DIR}
    sudo chmod -R 750 ${N8N_DIR}

    # Enable and start n8n
    sudo systemctl enable n8n
    sudo systemctl start n8n
}

setup_n8n