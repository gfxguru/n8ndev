#!/bin/bash
set -e

source ./config/settings.env
source ./scripts/utils/logging.sh
source ./scripts/ssl/check-ssl.sh

setup_nginx_ssl() {
    log_message "$LOG_INFO" "Setting up Nginx SSL configuration..."
    
    # Verify SSL certificate exists before proceeding
    if ! check_ssl_installed "${DOMAIN}"; then
        log_message "$LOG_ERROR" "SSL certificate must be installed before configuring Nginx"
        exit 1
    fi
    
    # Create SSL directory
    sudo mkdir -p /etc/nginx/ssl
    
    # Configure SSL parameters
    sudo tee /etc/nginx/conf.d/ssl-params.conf << EOF
# SSL parameters
ssl_protocols TLSv1.2 TLSv1.3;
ssl_prefer_server_ciphers off;
ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305;

# DH parameters
ssl_dhparam /etc/nginx/ssl/dhparam.pem;

# Session settings
ssl_session_timeout 1d;
ssl_session_cache shared:SSL:50m;
ssl_session_tickets off;

# OCSP Stapling
ssl_stapling on;
ssl_stapling_verify on;
resolver 8.8.8.8 8.8.4.4 valid=300s;
resolver_timeout 5s;

# HSTS
add_header Strict-Transport-Security "max-age=63072000" always;
EOF
    
    log_message "$LOG_INFO" "Nginx SSL configuration completed"
}