#!/bin/bash
set -e

source ./scripts/utils/logging.sh
source ./scripts/ssl/auto-renewal/timer-config.sh
source ./scripts/ssl/auto-renewal/service-config.sh

setup_apt_renewal() {
    log_message "$LOG_INFO" "Configuring APT-based Certbot auto-renewal..."
    
    # Create systemd timer
    get_timer_config | sudo tee /etc/systemd/system/certbot.timer > /dev/null
    
    # Create systemd service
    get_service_config "/usr/bin/certbot" | \
        sudo tee /etc/systemd/system/certbot.service > /dev/null
    
    # Enable and start timer
    sudo systemctl daemon-reload
    sudo systemctl enable certbot.timer
    sudo systemctl start certbot.timer
}