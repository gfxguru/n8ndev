#!/bin/bash
set -e

source ./config/settings.env

setup_backup() {
    echo "Setting up backup system..."
    
    # Create backup script
    sudo tee ${N8N_DIR}/scripts/backup.sh << EOF
#!/bin/bash

# Backup timestamp
TIMESTAMP=\$(date +%Y%m%d_%H%M%S)

# Backup PostgreSQL
PGPASSWORD=${POSTGRES_PASSWORD} pg_dump -U ${POSTGRES_USER} ${POSTGRES_DB} | \
    gzip > ${BACKUP_DIR}/database/n8n_db_\${TIMESTAMP}.sql.gz

# Backup Redis
redis-cli save
cp /var/lib/redis/dump.rdb ${BACKUP_DIR}/redis/redis_\${TIMESTAMP}.rdb

# Backup n8n data
tar -czf ${BACKUP_DIR}/n8n/n8n_data_\${TIMESTAMP}.tar.gz ${N8N_DIR}/data

# Remove old backups
find ${BACKUP_DIR} -type f -mtime +${BACKUP_RETENTION_DAYS} -delete

# Log backup completion
echo "\$(date): Backup completed" >> ${N8N_DIR}/logs/backup.log
EOF

    # Make backup script executable
    sudo chmod +x ${N8N_DIR}/scripts/backup.sh

    # Setup backup cron job
    sudo tee /etc/cron.d/n8n-backup << EOF
0 2 * * * root ${N8N_DIR}/scripts/backup.sh
EOF

    # Setup log rotation
    sudo tee /etc/logrotate.d/n8n << EOF
${N8N_DIR}/logs/*.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 640 n8n n8n
}
EOF
}

setup_backup