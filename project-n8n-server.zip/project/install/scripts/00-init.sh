#!/bin/bash
set -e

# Source configuration
source ./config/settings.env

# Create necessary directories
create_directories() {
    echo "Creating necessary directories..."
    sudo mkdir -p "$N8N_DIR"/{config,logs,data,scripts,backups}
    sudo mkdir -p "$BACKUP_DIR"/{database,redis,n8n}
    sudo mkdir -p /var/log/n8n
}

# Update system and install basic tools
update_system() {
    echo "Updating system packages..."
    sudo apt-get update
    sudo apt-get upgrade -y
    sudo apt-get install -y \
        curl \
        wget \
        git \
        unzip \
        ufw \
        fail2ban \
        logrotate \
        htop \
        net-tools \
        software-properties-common \
        apt-transport-https \
        ca-certificates \
        gnupg
}

# Configure basic security
setup_basic_security() {
    echo "Configuring basic security..."
    
    # Configure UFW
    sudo ufw default deny incoming
    sudo ufw default allow outgoing
    sudo ufw allow ssh
    sudo ufw allow http
    sudo ufw allow https
    sudo ufw --force enable

    # Configure fail2ban
    sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
    sudo systemctl enable fail2ban
    sudo systemctl start fail2ban
}

# Main execution
echo "Starting initial system setup..."
create_directories
update_system
setup_basic_security
echo "Initial setup completed!"