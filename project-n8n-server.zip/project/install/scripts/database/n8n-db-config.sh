#!/bin/bash
set -e

source ./config/settings.env

configure_n8n_database() {
    echo "Configuring n8n database settings..."
    
    # Create n8n database configuration
    sudo tee ${N8N_DIR}/config/database.env << EOF
# PostgreSQL Configuration
DB_TYPE=postgresdb
DB_POSTGRESDB_HOST=localhost
DB_POSTGRESDB_PORT=5432
DB_POSTGRESDB_DATABASE=${POSTGRES_DB}
DB_POSTGRESDB_USER=${POSTGRES_USER}
DB_POSTGRESDB_PASSWORD=${POSTGRES_PASSWORD}

# Redis Configuration
N8N_CACHE_ENABLED=true
N8N_REDIS_HOST=localhost
N8N_REDIS_PORT=${REDIS_PORT}
N8N_REDIS_PASSWORD=${REDIS_PASSWORD}
N8N_REDIS_DB=0

# Queue Configuration
QUEUE_BULL_REDIS_HOST=localhost
QUEUE_BULL_REDIS_PORT=${REDIS_PORT}
QUEUE_BULL_REDIS_PASSWORD=${REDIS_PASSWORD}
QUEUE_BULL_REDIS_DB=1
EOF

    # Ensure proper permissions
    sudo chown -R n8n:n8n ${N8N_DIR}/config
    sudo chmod 640 ${N8N_DIR}/config/database.env
}

configure_n8n_database