#!/bin/bash
set -e

# Function to validate domain name
validate_domain() {
    if [[ ! $1 =~ ^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$ ]]; then
        echo "Invalid domain name. Please enter a valid domain (e.g., example.com)"
        return 1
    fi
    return 0
}

# Function to validate email
validate_email() {
    if [[ ! $1 =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
        echo "Invalid email address. Please enter a valid email"
        return 1
    fi
    return 0
}

# Get domain and email
while true; do
    read -p "Enter domain name (e.g., example.com): " domain
    if validate_domain "$domain"; then
        break
    fi
done

while true; do
    read -p "Enter email address for SSL notifications: " email
    if validate_email "$email"; then
        break
    fi
done

# Update settings.env with domain and email
sed -i "s/DOMAIN=\"\"/DOMAIN=\"$domain\"/" ./config/settings.env
sed -i "s/EMAIL=\"\"/EMAIL=\"$email\"/" ./config/settings.env

echo "Configuration updated successfully!"