#!/bin/bash
set -e

# Source utilities
source ./scripts/utils/config.sh

# Initialize configuration
init_config

# Make scripts executable
chmod +x scripts/*.sh

# Run installation steps
./scripts/setup.sh      # Get configuration
./scripts/nodejs.sh     # Install Node.js
./scripts/postgres.sh   # Setup PostgreSQL
./scripts/n8n.sh       # Install n8n
./scripts/nginx.sh      # Setup Nginx
./scripts/ssl.sh       # Configure SSL

echo "Installation completed!"
echo "N8N is available at https://${DOMAIN}"