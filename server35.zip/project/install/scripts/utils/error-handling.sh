#!/bin/bash
set -e

# Error handling function
handle_error() {
    local exit_code=$?
    local line_number=$1
    echo "Error occurred in script at line $line_number"
    echo "Exit code: $exit_code"
    exit $exit_code
}

# Set up error trap
trap 'handle_error ${LINENO}' ERR