#!/bin/bash
set -e

# Load environment variables
load_config() {
    if [ -f ./config/settings.env ]; then
        source ./config/settings.env
    else
        echo "Error: settings.env not found"
        exit 1
    fi
}

# Validate configuration
validate_config() {
    local errors=0

    # Check required variables
    for var in DOMAIN EMAIL N8N_PORT NODE_VERSION POSTGRES_DB POSTGRES_USER; do
        if [ -z "${!var}" ]; then
            echo "Error: $var is not set"
            errors=$((errors + 1))
        fi
    done

    # Generate PostgreSQL password if not set
    if [ -z "$POSTGRES_PASSWORD" ]; then
        POSTGRES_PASSWORD=$(openssl rand -hex 24)
        sed -i "s/POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=\"$POSTGRES_PASSWORD\"/" ./config/settings.env
    fi

    # Validate domain format
    if [[ ! $DOMAIN =~ ^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$ ]]; then
        echo "Error: Invalid domain format"
        errors=$((errors + 1))
    fi

    # Validate email format
    if [[ ! $EMAIL =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
        echo "Error: Invalid email format"
        errors=$((errors + 1))
    fi

    if [ $errors -gt 0 ]; then
        echo "Found $errors configuration error(s)"
        exit 1
    fi
}

# Initialize configuration
init_config() {
    load_config
    validate_config
}