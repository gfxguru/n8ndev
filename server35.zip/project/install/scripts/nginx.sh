#!/bin/bash
set -e

source ./config/settings.env

setup_nginx() {
    echo "Setting up Nginx..."
    
    # Install Nginx
    sudo apt-get install -y nginx
    
    # Create configuration directories
    sudo mkdir -p /etc/nginx/conf.d
    
    # Copy configuration files
    sudo cp ./scripts/nginx/conf.d/*.conf /etc/nginx/conf.d/
    
    # Enable site and remove default
    sudo rm -f /etc/nginx/sites-enabled/default
    
    # Test and restart Nginx
    if sudo nginx -t; then
        sudo systemctl restart nginx
    else
        echo "Nginx configuration test failed!"
        exit 1
    fi
}

setup_nginx