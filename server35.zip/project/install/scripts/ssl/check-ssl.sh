#!/bin/bash
set -e

source ./scripts/utils/logging.sh

check_ssl_installed() {
    local domain="$1"
    local cert_path="/etc/letsencrypt/live/${domain}/fullchain.pem"
    local key_path="/etc/letsencrypt/live/${domain}/privkey.pem"
    
    if [ ! -f "$cert_path" ] || [ ! -f "$key_path" ]; then
        log_message "$LOG_WARNING" "SSL certificate not found for ${domain}"
        return 1
    fi
    
    # Verify certificate validity
    if ! sudo openssl x509 -in "$cert_path" -noout -checkend 0; then
        log_message "$LOG_WARNING" "SSL certificate for ${domain} has expired"
        return 1
    fi
    
    log_message "$LOG_INFO" "Valid SSL certificate found for ${domain}"
    return 0
}