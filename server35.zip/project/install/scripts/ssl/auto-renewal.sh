#!/bin/bash
set -e

source ./scripts/utils/logging.sh
source ./scripts/ssl/auto-renewal/setup-snap.sh
source ./scripts/ssl/auto-renewal/setup-apt.sh
source ./scripts/ssl/auto-renewal/nginx-hook.sh

setup_auto_renewal() {
    log_message "$LOG_INFO" "Setting up monthly SSL certificate auto-renewal..."
    
    # Setup Nginx hook first
    setup_nginx_hook
    
    # Determine installation method and configure accordingly
    if command -v snap >/dev/null && snap list certbot >/dev/null 2>&1; then
        setup_snap_renewal
    else
        setup_apt_renewal
    fi
    
    # Verify timer status
    if systemctl is-active --quiet snap.certbot.renew.timer 2>/dev/null || \
       systemctl is-active --quiet certbot.timer 2>/dev/null; then
        log_message "$LOG_INFO" "Auto-renewal configured successfully"
    else
        log_message "$LOG_ERROR" "Failed to configure auto-renewal"
        exit 1
    fi
}