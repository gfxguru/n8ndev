#!/bin/bash
set -e

source ./scripts/utils/logging.sh
source ./scripts/ssl/auto-renewal/timer-config.sh
source ./scripts/ssl/auto-renewal/service-config.sh

setup_snap_renewal() {
    log_message "$LOG_INFO" "Configuring snap-based Certbot auto-renewal..."
    
    # Configure snap
    sudo snap set certbot trust-plugin-with-root=ok
    sudo snap refresh --time
    
    # Create systemd timer
    get_timer_config | sudo tee /etc/systemd/system/snap.certbot.renew.timer > /dev/null
    
    # Create systemd service
    get_service_config "/snap/bin/certbot" | \
        sudo tee /etc/systemd/system/snap.certbot.renew.service > /dev/null
    
    # Enable and start timer
    sudo systemctl daemon-reload
    sudo systemctl enable snap.certbot.renew.timer
    sudo systemctl start snap.certbot.renew.timer
}