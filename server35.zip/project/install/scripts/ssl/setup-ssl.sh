#!/bin/bash
set -e

source ./scripts/utils/logging.sh
source ./scripts/ssl/certbot-utils.sh
source ./scripts/ssl/dhparam-utils.sh

setup_ssl() {
    log_message "$LOG_INFO" "Setting up SSL..."
    
    # Install and verify Certbot
    install_certbot
    verify_certbot_installation
    
    # Generate DH parameters
    generate_dhparam
    
    # Configure auto-renewal
    source ./scripts/ssl/auto-renewal.sh
    setup_auto_renewal
    
    log_message "$LOG_INFO" "SSL setup completed"
}