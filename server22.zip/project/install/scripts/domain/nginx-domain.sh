#!/bin/bash
set -e

source ./config/settings.env
source ./scripts/ssl/check-ssl.sh
source ./scripts/domain/nginx-config-templates.sh

configure_nginx_domain() {
    local domain="$DOMAIN"
    local port="$N8N_PORT"

    echo "Configuring Nginx domain settings for ${domain}..."
    
    # Check SSL certificate before proceeding
    if ! check_ssl_installed "$domain"; then
        echo "SSL certificate not found for ${domain}"
        echo "Please ensure SSL is properly installed before configuring Nginx"
        exit 1
    fi
    
    # Create Nginx configuration using template
    create_nginx_config "$domain" "$port" > "/etc/nginx/sites-available/n8n"

    # Enable the site and remove default
    sudo rm -f /etc/nginx/sites-enabled/default
    sudo ln -sf /etc/nginx/sites-available/n8n /etc/nginx/sites-enabled/

    # Test and reload Nginx
    if sudo nginx -t; then
        echo "Nginx configuration test passed. Reloading Nginx..."
        sudo systemctl reload nginx
    else
        echo "Nginx configuration test failed. Please check the configuration."
        exit 1
    fi
}

configure_nginx_domain