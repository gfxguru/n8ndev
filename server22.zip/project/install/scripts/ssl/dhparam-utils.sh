#!/bin/bash
set -e

source ./scripts/utils/logging.sh

generate_dhparam() {
    local dhparam_path="/etc/nginx/ssl/dhparam.pem"
    
    if [ ! -f "$dhparam_path" ]; then
        log_message "$LOG_INFO" "Generating DH parameters (2048 bit) - this may take a few minutes..."
        sudo mkdir -p /etc/nginx/ssl
        sudo openssl dhparam -out "$dhparam_path" 2048
        sudo chmod 644 "$dhparam_path"
    else
        log_message "$LOG_INFO" "DH parameters already exist"
    fi
}