#!/bin/bash
set -e

source ./scripts/utils/logging.sh

get_service_config() {
    local certbot_path="$1"
    
    cat << EOF
[Unit]
Description=Certbot Renewal Service
Documentation=https://certbot.eff.org/
After=network-online.target

[Service]
Type=oneshot
ExecStart=${certbot_path} renew --quiet --agree-tos
ExecStartPost=/bin/systemctl reload nginx.service

[Install]
WantedBy=multi-user.target
EOF
}