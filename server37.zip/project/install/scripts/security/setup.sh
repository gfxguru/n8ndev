#!/bin/bash
set -e

source ./scripts/utils/logging.sh
source ./scripts/security/utils/validation.sh
source ./scripts/security/modules/firewall.sh
source ./scripts/security/modules/fail2ban.sh
source ./scripts/security/modules/hardening.sh

setup_security() {
    log_message "INFO" "Setting up security components..."
    
    # Validate requirements
    validate_security_requirements
    
    # Setup firewall
    setup_firewall
    
    # Setup fail2ban
    setup_fail2ban
    
    # Apply system hardening
    apply_system_hardening
    
    log_message "INFO" "Security setup completed"
}