#!/bin/bash
set -e

source ./scripts/utils/logging.sh

verify_security_configuration() {
    log_message "INFO" "Verifying security configuration..."
    
    # Check UFW status
    if ! sudo ufw status | grep -q "Status: active"; then
        log_message "ERROR" "UFW is not active"
        return 1
    fi
    
    # Check fail2ban status
    if ! systemctl is-active --quiet fail2ban; then
        log_message "ERROR" "fail2ban is not active"
        return 1
    fi
    
    # Verify SSH configuration
    if ! sshd -t; then
        log_message "ERROR" "Invalid SSH configuration"
        return 1
    fi
    
    log_message "INFO" "Security verification completed"
    return 0
}