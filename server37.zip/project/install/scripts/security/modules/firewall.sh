#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_firewall() {
    log_message "INFO" "Setting up firewall..."
    
    # Install UFW if not present
    if ! command -v ufw &> /dev/null; then
        sudo apt-get install -y ufw
    fi
    
    # Reset UFW to default state
    sudo ufw --force reset
    
    # Default policies
    sudo ufw default deny incoming
    sudo ufw default allow outgoing
    
    # Allow SSH (port 22)
    sudo ufw allow ssh
    
    # Allow HTTP and HTTPS
    sudo ufw allow http
    sudo ufw allow https
    
    # Allow n8n port if not using reverse proxy
    if [ "${N8N_PORT}" != "80" ] && [ "${N8N_PORT}" != "443" ]; then
        sudo ufw allow ${N8N_PORT}/tcp
    fi
    
    # Enable UFW
    sudo ufw --force enable
    
    # Verify UFW status
    if ! sudo ufw status | grep -q "Status: active"; then
        log_message "ERROR" "Failed to enable UFW"
        exit 1
    fi
    
    log_message "INFO" "Firewall setup completed"
}