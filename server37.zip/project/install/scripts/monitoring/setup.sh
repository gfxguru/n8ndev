#!/bin/bash
set -e

source ./scripts/utils/logging.sh
source ./scripts/monitoring/utils/validation.sh
source ./scripts/monitoring/modules/monit.sh
source ./scripts/monitoring/modules/logging.sh
source ./scripts/monitoring/modules/alerts.sh

setup_monitoring() {
    log_message "INFO" "Setting up monitoring system..."
    
    # Validate requirements
    validate_monitoring_requirements
    
    # Setup Monit monitoring
    setup_monit_monitoring
    
    # Setup logging
    setup_logging
    
    # Setup alerts
    setup_monitoring_alerts
    
    log_message "INFO" "Monitoring system setup completed"
}