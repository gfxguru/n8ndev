#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_logging() {
    log_message "INFO" "Setting up log rotation..."
    
    # Configure logrotate for n8n
    sudo tee /etc/logrotate.d/n8n << EOF
${N8N_DIR}/logs/*.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 640 n8n n8n
    sharedscripts
    postrotate
        systemctl reload n8n
    endscript
}
EOF
    
    # Set proper permissions
    sudo chmod 644 /etc/logrotate.d/n8n
}