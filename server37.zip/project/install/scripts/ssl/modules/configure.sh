#!/bin/bash
set -e

source ./scripts/utils/logging.sh

configure_ssl() {
    log_message "INFO" "Configuring SSL..."
    
    # Stop Nginx temporarily
    sudo systemctl stop nginx
    
    # Obtain certificate
    sudo certbot certonly \
        --standalone \
        --non-interactive \
        --agree-tos \
        --email "${EMAIL}" \
        --domains "${DOMAIN}" \
        --rsa-key-size 4096
    
    # Verify certificate
    if [ ! -f "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" ]; then
        log_message "ERROR" "SSL certificate installation failed"
        exit 1
    fi
    
    # Start Nginx
    sudo systemctl start nginx
}