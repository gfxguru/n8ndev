#!/bin/bash
set -e

source ./scripts/utils/logging.sh
source ./scripts/ssl/utils/certbot.sh

install_ssl_components() {
    log_message "INFO" "Installing SSL components..."
    
    # Install Certbot
    install_certbot
    verify_certbot
    
    # Create required directories
    sudo mkdir -p /etc/letsencrypt
    sudo mkdir -p /var/lib/letsencrypt
    sudo mkdir -p /var/log/letsencrypt
    
    # Set proper permissions
    sudo chown -R root:root /etc/letsencrypt
    sudo chmod 755 /etc/letsencrypt
}