#!/bin/bash
set -e

source ./scripts/utils/logging.sh

install_n8n() {
    log_message "INFO" "Installing n8n..."
    sudo npm install -g n8n
}

setup_n8n_user() {
    log_message "INFO" "Setting up n8n user..."
    sudo useradd -r -s /bin/false n8n || true
    sudo mkdir -p "${N8N_DIR}"/{config,data}
}

create_n8n_config() {
    log_message "INFO" "Creating n8n configuration..."
    sudo tee "${N8N_DIR}/config/.env" << EOF
DB_TYPE=postgresdb
DB_POSTGRESDB_HOST=localhost
DB_POSTGRESDB_DATABASE=${POSTGRES_DB}
DB_POSTGRESDB_USER=${POSTGRES_USER}
DB_POSTGRESDB_PASSWORD=${POSTGRES_PASSWORD}
N8N_HOST=${DOMAIN}
N8N_PORT=${N8N_PORT}
N8N_PROTOCOL=https
N8N_USER_FOLDER="${N8N_DIR}/data"
EOF
}

create_n8n_service() {
    log_message "INFO" "Creating n8n service..."
    sudo tee /etc/systemd/system/n8n.service << EOF
[Unit]
Description=n8n Workflow Automation
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=n8n
EnvironmentFile=${N8N_DIR}/config/.env
ExecStart=/usr/bin/n8n start
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
}

configure_permissions() {
    log_message "INFO" "Setting up permissions..."
    sudo chown -R n8n:n8n "${N8N_DIR}"
    sudo chmod 600 "${N8N_DIR}/config/.env"
}

start_n8n_service() {
    log_message "INFO" "Starting n8n service..."
    sudo systemctl daemon-reload
    sudo systemctl enable n8n
    sudo systemctl start n8n
}

verify_n8n() {
    if ! systemctl is-active --quiet n8n; then
        log_message "ERROR" "n8n service failed to start"
        exit 1
    fi
    log_message "INFO" "n8n setup completed successfully"
}

setup_n8n() {
    install_n8n
    setup_n8n_user
    create_n8n_config
    create_n8n_service
    configure_permissions
    start_n8n_service
    verify_n8n
}