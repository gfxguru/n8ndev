#!/bin/bash
set -e

source ./scripts/utils/logging.sh

install_nodejs() {
    log_message "INFO" "Installing Node.js ${NODE_VERSION}..."
    curl -fsSL "https://deb.nodesource.com/setup_${NODE_VERSION}.x" | sudo -E bash -
    sudo apt-get install -y nodejs
}

verify_nodejs() {
    if ! command -v node >/dev/null || ! command -v npm >/dev/null; then
        log_message "ERROR" "Node.js installation failed"
        exit 1
    fi
    log_message "INFO" "Node.js $(node --version) installed successfully"
}

setup_nodejs() {
    install_nodejs
    verify_nodejs
}