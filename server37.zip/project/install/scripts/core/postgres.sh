#!/bin/bash
set -e

source ./scripts/utils/logging.sh

install_postgres() {
    log_message "INFO" "Installing PostgreSQL..."
    sudo apt-get install -y postgresql postgresql-contrib
}

configure_postgres() {
    log_message "INFO" "Configuring PostgreSQL..."
    sudo systemctl start postgresql
    sudo systemctl enable postgresql
    
    sudo -u postgres psql << EOF
CREATE USER ${POSTGRES_USER} WITH PASSWORD '${POSTGRES_PASSWORD}';
CREATE DATABASE ${POSTGRES_DB} OWNER ${POSTGRES_USER};
EOF
}

verify_postgres() {
    if ! sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw "${POSTGRES_DB}"; then
        log_message "ERROR" "PostgreSQL database creation failed"
        exit 1
    fi
    log_message "INFO" "PostgreSQL configured successfully"
}

setup_postgres() {
    install_postgres
    configure_postgres
    verify_postgres
}