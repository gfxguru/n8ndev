#!/bin/bash
set -e

source ./scripts/utils/logging.sh

install_postgres_components() {
    log_message "INFO" "Installing PostgreSQL ${POSTGRES_VERSION}..."
    
    # Add PostgreSQL repository
    sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
    wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
    
    # Update package lists
    sudo apt-get update
    
    # Install PostgreSQL
    sudo apt-get install -y \
        postgresql-${POSTGRES_VERSION} \
        postgresql-contrib-${POSTGRES_VERSION} \
        postgresql-client-${POSTGRES_VERSION}
    
    # Verify installation
    if ! command -v psql &> /dev/null; then
        log_message "ERROR" "PostgreSQL installation failed"
        exit 1
    fi
    
    log_message "INFO" "PostgreSQL installed successfully"
}