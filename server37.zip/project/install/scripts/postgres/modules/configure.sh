#!/bin/bash
set -e

source ./scripts/utils/logging.sh

configure_postgres() {
    log_message "INFO" "Configuring PostgreSQL..."
    
    # Create database and user
    sudo -u postgres psql << EOF
CREATE DATABASE ${POSTGRES_DB};
CREATE USER ${POSTGRES_USER} WITH ENCRYPTED PASSWORD '${POSTGRES_PASSWORD}';
GRANT ALL PRIVILEGES ON DATABASE ${POSTGRES_DB} TO ${POSTGRES_USER};
ALTER DATABASE ${POSTGRES_DB} OWNER TO ${POSTGRES_USER};
EOF
    
    # Configure PostgreSQL settings
    sudo tee /etc/postgresql/${POSTGRES_VERSION}/main/conf.d/n8n_optimizations.conf << EOF
# Memory settings
shared_buffers = 256MB
work_mem = 16MB
maintenance_work_mem = 128MB
effective_cache_size = 1GB

# Connection settings
max_connections = 100
max_worker_processes = 8
max_parallel_workers_per_gather = 4
max_parallel_workers = 8

# WAL settings
wal_level = replica
max_wal_size = 1GB
min_wal_size = 80MB

# Query planner settings
random_page_cost = 1.1
effective_io_concurrency = 200
EOF
    
    # Restart PostgreSQL to apply settings
    sudo systemctl restart postgresql
    
    # Verify database exists
    if ! sudo -u postgres psql -lqt | cut -d \| -f 1 | grep -qw "${POSTGRES_DB}"; then
        log_message "ERROR" "Database creation failed"
        exit 1
    fi
    
    log_message "INFO" "PostgreSQL configuration completed"
}