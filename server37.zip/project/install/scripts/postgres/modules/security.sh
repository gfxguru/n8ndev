#!/bin/bash
set -e

source ./scripts/utils/logging.sh

secure_postgres() {
    log_message "INFO" "Applying PostgreSQL security settings..."
    
    # Configure pg_hba.conf
    sudo tee /etc/postgresql/${POSTGRES_VERSION}/main/pg_hba.conf << EOF
# TYPE  DATABASE        USER            ADDRESS                 METHOD
local   all            postgres                                peer
local   all            all                                     md5
host    all            all             127.0.0.1/32           md5
host    all            all             ::1/128                md5
EOF
    
    # Set proper permissions
    sudo chmod 640 /etc/postgresql/${POSTGRES_VERSION}/main/pg_hba.conf
    sudo chown postgres:postgres /etc/postgresql/${POSTGRES_VERSION}/main/pg_hba.conf
    
    # Restart PostgreSQL to apply security settings
    sudo systemctl restart postgresql
    
    log_message "INFO" "PostgreSQL security settings applied"
}