#!/bin/bash
set -e

source ./scripts/utils/logging.sh

install_n8n_components() {
    log_message "INFO" "Installing n8n..."
    
    # Install n8n globally
    sudo npm install -g n8n
    
    # Create n8n user
    sudo useradd -r -s /bin/false n8n || true
    
    # Create required directories
    sudo mkdir -p "${N8N_DIR}"/{config,data,logs}
    
    # Set proper permissions
    sudo chown -R n8n:n8n "${N8N_DIR}"
    sudo chmod 750 "${N8N_DIR}"
    
    # Verify installation
    if ! command -v n8n &> /dev/null; then
        log_message "ERROR" "n8n installation failed"
        exit 1
    fi
    
    log_message "INFO" "n8n installed successfully"
}