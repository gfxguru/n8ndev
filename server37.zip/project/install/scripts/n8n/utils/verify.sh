#!/bin/bash
set -e

source ./scripts/utils/logging.sh

verify_n8n_installation() {
    log_message "INFO" "Verifying n8n installation..."
    
    # Check if n8n is installed
    if ! command -v n8n &> /dev/null; then
        log_message "ERROR" "n8n is not installed"
        return 1
    fi
    
    # Check version
    local version=$(n8n --version)
    log_message "INFO" "n8n version ${version} installed"
    return 0
}

verify_n8n_service() {
    log_message "INFO" "Verifying n8n service..."
    
    # Check if service is running
    if ! systemctl is-active --quiet n8n; then
        log_message "ERROR" "n8n service is not running"
        return 1
    fi
    
    # Check if port is listening
    if ! netstat -tuln | grep -q ":${N8N_PORT} "; then
        log_message "ERROR" "n8n is not listening on port ${N8N_PORT}"
        return 1
    fi
    
    log_message "INFO" "n8n service verification completed"
    return 0
}