#!/bin/bash
set -e

source ./scripts/utils/logging.sh

validate_n8n_requirements() {
    log_message "INFO" "Validating n8n requirements..."
    
    # Check Node.js version
    if [ -z "${NODE_VERSION}" ]; then
        log_message "ERROR" "Node.js version is not set"
        exit 1
    fi
    
    # Check n8n port
    if [ -z "${N8N_PORT}" ]; then
        log_message "ERROR" "n8n port is not set"
        exit 1
    fi
    
    # Validate port number
    if ! [[ "${N8N_PORT}" =~ ^[0-9]+$ ]] || [ "${N8N_PORT}" -lt 1024 ] || [ "${N8N_PORT}" -gt 65535 ]; then
        log_message "ERROR" "Invalid port number: ${N8N_PORT}"
        exit 1
    fi
    
    # Check database configuration
    if [ -z "${POSTGRES_DB}" ] || [ -z "${POSTGRES_USER}" ] || [ -z "${POSTGRES_PASSWORD}" ]; then
        log_message "ERROR" "Database configuration is incomplete"
        exit 1
    fi
}