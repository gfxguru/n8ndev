#!/bin/bash
set -e

source ./scripts/utils/logging.sh
source ./scripts/n8n/utils/validation.sh
source ./scripts/n8n/modules/install.sh
source ./scripts/n8n/modules/configure.sh
source ./scripts/n8n/modules/service.sh

setup_n8n() {
    log_message "INFO" "Starting n8n setup..."
    
    # Validate requirements
    validate_n8n_requirements
    
    # Install n8n
    install_n8n_components
    
    # Configure n8n
    configure_n8n
    
    # Setup service
    setup_n8n_service
    
    log_message "INFO" "n8n setup completed successfully"
}