#!/bin/bash
set -e

source ./scripts/utils/validation.sh

setup_config() {
    # Create settings file if it doesn't exist
    if [ ! -f ./config/settings.env ]; then
        cp ./config/settings.env.example ./config/settings.env
    fi

    # Load current settings
    source ./config/settings.env

    # Get and validate domain
    while true; do
        if [ -z "$DOMAIN" ]; then
            read -p "Enter domain name (e.g., example.com): " domain
            if validate_domain "$domain"; then
                sed -i "s/DOMAIN=.*/DOMAIN=\"$domain\"/" ./config/settings.env
                break
            else
                echo "Invalid domain format"
            fi
        else
            break
        fi
    done

    # Get and validate email
    while true; do
        if [ -z "$EMAIL" ]; then
            read -p "Enter email address: " email
            if validate_email "$email"; then
                sed -i "s/EMAIL=.*/EMAIL=\"$email\"/" ./config/settings.env
                break
            else
                echo "Invalid email format"
            fi
        else
            break
        fi
    done

    # Generate PostgreSQL password if not set
    if [ -z "$POSTGRES_PASSWORD" ]; then
        POSTGRES_PASSWORD=$(openssl rand -hex 24)
        sed -i "s/POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=\"$POSTGRES_PASSWORD\"/" ./config/settings.env
    fi

    # Reload settings
    source ./config/settings.env
}

setup_config