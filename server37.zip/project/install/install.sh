#!/bin/bash
set -e

# Source utilities
source ./scripts/utils/logging.sh
source ./scripts/utils/os-check.sh

# Check Ubuntu version
check_ubuntu_version

log_message "INFO" "Starting n8n installation..."

# Make scripts executable
chmod +x scripts/**/*.sh

# Setup configuration
./scripts/setup.sh

# Source configuration
source ./config/settings.env

# Run installation steps
./scripts/core/nodejs.sh
./scripts/core/postgres.sh
./scripts/core/n8n.sh
./scripts/nginx/setup.sh
./scripts/ssl/setup.sh

log_message "INFO" "Installation completed successfully!"
log_message "INFO" "n8n is available at https://${DOMAIN}"
log_message "INFO" "Please save your credentials from config/settings.env"