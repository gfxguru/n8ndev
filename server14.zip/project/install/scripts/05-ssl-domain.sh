#!/bin/bash
set -e

source ./config/settings.env

# Source modular components
source ./scripts/ssl/certbot.sh
source ./scripts/ssl/nginx-ssl.sh
source ./scripts/domain/nginx-domain.sh
source ./scripts/domain/n8n-domain.sh

echo "Setting up SSL and domain configuration..."

# Step 1: Configure initial HTTP setup
configure_initial_nginx

# Step 2: Install and configure SSL
install_certbot
obtain_ssl_certificate

# Step 3: Configure SSL settings
configure_nginx_ssl

# Step 4: Configure domain settings
configure_nginx_domain
configure_n8n_domain