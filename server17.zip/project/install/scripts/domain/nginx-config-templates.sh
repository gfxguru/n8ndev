#!/bin/bash
set -e

create_nginx_config() {
    local domain="$1"
    local port="$2"

    cat << EOF
# HTTP - redirect all requests to HTTPS
server {
    listen 80;
    listen [::]:80;
    server_name ${domain};
    return 301 https://\$server_name\$request_uri;
}

# HTTPS - proxy requests to n8n
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name ${domain};

    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/${domain}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${domain}/privkey.pem;
    include /etc/nginx/conf.d/ssl-params.conf;
    
    # Cache Configuration
    include /etc/nginx/conf.d/proxy-cache.conf;
    
    location / {
        proxy_pass http://127.0.0.1:${port};
        proxy_http_version 1.1;
        
        # Include common proxy settings
        include /etc/nginx/conf.d/proxy-params.conf;
        
        # Cache settings
        proxy_cache n8n_cache;
        proxy_cache_use_stale error timeout http_500 http_502 http_503 http_504;
        proxy_cache_background_update on;
        proxy_cache_lock on;
        proxy_cache_valid 200 60m;
        proxy_cache_bypass \$skip_cache;
        proxy_no_cache \$skip_cache;
        add_header X-Cache-Status \$upstream_cache_status;
    }
    
    # Security headers
    include /etc/nginx/conf.d/security-headers.conf;
}
EOF
}