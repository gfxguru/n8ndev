#!/bin/bash
set -e

source ./config/settings.env

configure_n8n_domain() {
    echo "Configuring n8n domain settings..."
    
    # Create n8n environment configuration
    sudo mkdir -p ${N8N_DIR}/config
    sudo tee ${N8N_DIR}/config/domain.env << EOF
# Domain Configuration
N8N_HOST="${DOMAIN}"
N8N_PROTOCOL="https"
N8N_PORT=${N8N_PORT}
N8N_EDITOR_BASE_URL="https://${DOMAIN}"

# Security Settings
N8N_ENCRYPTION_KEY="$(openssl rand -hex 24)"
N8N_BASIC_AUTH_ACTIVE=true

# CORS Settings
N8N_CORS_ENABLE=true
N8N_CORS_ALLOWED_ORIGINS="https://${DOMAIN}"
EOF

    # Ensure proper permissions
    sudo chown -R n8n:n8n ${N8N_DIR}/config
    sudo chmod 640 ${N8N_DIR}/config/domain.env
}

configure_n8n_domain