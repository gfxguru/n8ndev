#!/bin/bash
set -e

check_ubuntu_version() {
    # Get Ubuntu version
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        UBUNTU_VERSION="${VERSION_ID}"
    else
        echo "Error: Cannot determine Ubuntu version"
        exit 1
    fi

    # Check if version is supported (20.04, 22.04, or 24.04)
    case "$UBUNTU_VERSION" in
        "20.04"|"22.04"|"24.04")
            echo "Ubuntu ${UBUNTU_VERSION} detected"
            ;;
        *)
            echo "Unsupported Ubuntu version: ${UBUNTU_VERSION}"
            echo "This script requires Ubuntu 20.04, 22.04, or 24.04"
            exit 1
            ;;
    esac
}