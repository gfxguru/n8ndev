#!/bin/bash
set -e

source ./scripts/utils/logging.sh

verify_certbot_installation() {
    if ! command -v certbot >/dev/null 2>&1; then
        log_message "$LOG_ERROR" "Certbot is not installed"
        return 1
    fi
    
    # Check if snap version is used (Ubuntu 24.04)
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        if [[ "${VERSION_ID}" == "24.04" ]]; then
            if ! snap list certbot >/dev/null 2>&1; then
                log_message "$LOG_WARNING" "Certbot should be installed via snap on Ubuntu 24.04"
                return 1
            fi
        fi
    fi
    
    return 0
}