#!/bin/bash
set -e

source ./scripts/utils/logging.sh

generate_dhparam() {
    local dhparam_path="/etc/nginx/ssl/dhparam.pem"
    local dhparam_size=2048

    # Check Ubuntu version for potential optimizations
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        if [[ "${VERSION_ID}" == "24.04" ]]; then
            # Use larger key size for newer Ubuntu versions
            dhparam_size=4096
        fi
    fi

    if [ ! -f "$dhparam_path" ]; then
        log_message "$LOG_INFO" "Generating DH parameters (${dhparam_size} bit) - this may take a few minutes..."
        sudo openssl dhparam -out "$dhparam_path" "$dhparam_size"
    else
        log_message "$LOG_INFO" "DH parameters already exist"
    fi
}