#!/bin/bash
set -e

source ./config/settings.env

setup_n8n() {
    echo "Setting up n8n..."
    
    # Install n8n globally
    sudo npm install -g n8n

    # Create n8n system user
    sudo useradd -r -s /bin/false n8n || true

    # Create required directories
    sudo mkdir -p ${N8N_DIR}/{config,logs,data}
    
    # Create unified environment file
    sudo tee ${N8N_DIR}/config/.env << EOF
# Load other configurations
source ${N8N_DIR}/config/database.env
source ${N8N_DIR}/config/domain.env

# Application Settings
N8N_USER_FOLDER="${N8N_DIR}/data"
N8N_LOG_LEVEL="info"
N8N_LOG_OUTPUT="${N8N_DIR}/logs/n8n.log"
N8N_ENCRYPTION_KEY="$(openssl rand -hex 24)"
EXECUTIONS_DATA_PRUNE=true
EXECUTIONS_DATA_MAX_AGE=168
EXECUTIONS_DATA_PRUNE_TIMEOUT=7200
GENERIC_TIMEZONE="UTC"

# Performance Settings
NODE_OPTIONS="--max-old-space-size=4096"
EOF

    # Create systemd service
    sudo tee /etc/systemd/system/n8n.service << EOF
[Unit]
Description=n8n Workflow Automation
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=n8n
EnvironmentFile=${N8N_DIR}/config/.env
ExecStart=/usr/bin/n8n start
Restart=always
RestartSec=10
WorkingDirectory=${N8N_DIR}
StandardOutput=append:${N8N_DIR}/logs/n8n-output.log
StandardError=append:${N8N_DIR}/logs/n8n-error.log

[Install]
WantedBy=multi-user.target
EOF

    # Set permissions
    sudo chown -R n8n:n8n ${N8N_DIR}
    sudo chmod -R 750 ${N8N_DIR}
    sudo chmod 640 ${N8N_DIR}/config/.env

    # Reload systemd and start n8n
    sudo systemctl daemon-reload
    sudo systemctl enable n8n
    sudo systemctl restart n8n

    # Wait for n8n to start
    echo "Waiting for n8n to start..."
    sleep 10

    # Check n8n status
    if sudo systemctl is-active --quiet n8n; then
        echo "n8n started successfully!"
    else
        echo "Error: n8n failed to start. Checking logs..."
        sudo journalctl -u n8n -n 50
        exit 1
    fi
}

setup_n8n