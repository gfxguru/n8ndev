#!/bin/bash
set -e

source ./scripts/utils/logging.sh

get_timer_config() {
    cat << EOF
[Unit]
Description=Monthly Certbot Renewal Timer
Documentation=https://certbot.eff.org/
After=network-online.target

[Timer]
# Run on the first day of each month at 3 AM
OnCalendar=*-*-01 03:00:00
RandomizedDelaySec=3600
Persistent=true

[Install]
WantedBy=timers.target
EOF
}