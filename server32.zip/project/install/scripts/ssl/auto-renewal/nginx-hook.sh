#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_nginx_hook() {
    log_message "$LOG_INFO" "Setting up Nginx reload hook..."
    
    # Create hook directory
    sudo mkdir -p /etc/letsencrypt/renewal-hooks/post
    
    # Create reload hook
    local hook_path="/etc/letsencrypt/renewal-hooks/post/nginx-reload"
    cat << EOF | sudo tee "$hook_path" > /dev/null
#!/bin/bash
systemctl reload nginx
EOF
    
    sudo chmod +x "$hook_path"
}