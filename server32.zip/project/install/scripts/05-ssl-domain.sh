#!/bin/bash
set -e

source ./config/settings.env
source ./scripts/utils/logging.sh

# Step 1: Set up SSL
source ./scripts/ssl/setup-ssl.sh
setup_ssl

# Step 2: Configure Nginx SSL
source ./scripts/nginx/setup-nginx-ssl.sh
setup_nginx_ssl

# Step 3: Configure Nginx domain
source ./scripts/domain/nginx-domain.sh
configure_nginx_domain

log_message "$LOG_INFO" "SSL and domain configuration completed successfully!"