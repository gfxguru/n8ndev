#!/bin/bash
set -e

source ./scripts/utils/logging.sh
source ./scripts/nginx/setup-nginx.sh

# Main Nginx setup
log_message "$LOG_INFO" "Starting Nginx installation and configuration..."

# Install Nginx
apt-get update
apt-get install -y nginx

# Configure Nginx
setup_nginx

# Test configuration
if nginx -t; then
    log_message "$LOG_INFO" "Nginx configuration test passed"
    systemctl restart nginx
else
    log_message "$LOG_ERROR" "Nginx configuration test failed!"
    exit 1
fi

log_message "$LOG_INFO" "Nginx setup completed successfully"