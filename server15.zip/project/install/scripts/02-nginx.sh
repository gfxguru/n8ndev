#!/bin/bash
set -e

source ./config/settings.env

setup_nginx() {
    echo "Setting up Nginx..."
    
    # Install Nginx
    sudo apt-get install -y nginx

    # Create required directories
    sudo mkdir -p /etc/nginx/conf.d
    sudo mkdir -p /var/cache/nginx/n8n
    sudo chown -R www-data:www-data /var/cache/nginx/n8n
    sudo chmod 700 /var/cache/nginx/n8n

    # Copy configuration files
    sudo cp ./scripts/nginx/conf.d/*.conf /etc/nginx/conf.d/

    # Test configuration
    if sudo nginx -t; then
        echo "Nginx configuration test passed. Starting Nginx..."
        sudo systemctl restart nginx
    else
        echo "Nginx configuration test failed!"
        exit 1
    fi
}

setup_nginx