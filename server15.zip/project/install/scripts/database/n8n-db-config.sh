#!/bin/bash
set -e

source ./config/settings.env

configure_n8n_database() {
    echo "Configuring n8n database settings..."
    
    # Create n8n database configuration
    sudo tee ${N8N_DIR}/config/database.env << EOF
# PostgreSQL Configuration
DB_TYPE=postgresdb
DB_POSTGRESDB_HOST=localhost
DB_POSTGRESDB_PORT=5432
DB_POSTGRESDB_DATABASE=${POSTGRES_DB}
DB_POSTGRESDB_USER=${POSTGRES_USER}
DB_POSTGRESDB_PASSWORD=${POSTGRES_PASSWORD}

# Queue Configuration
QUEUE_MODE=bull
EOF

    # Ensure proper permissions
    sudo chown -R n8n:n8n ${N8N_DIR}/config
    sudo chmod 640 ${N8N_DIR}/config/database.env
}

configure_n8n_database