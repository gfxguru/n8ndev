# n8n Server Installation Scripts

Automated installation scripts for setting up n8n on Ubuntu with Nginx, PostgreSQL, Redis, and SSL.

## Features

- 🔒 Secure SSL configuration with Let's Encrypt
- 🗄️ PostgreSQL database setup
- 📦 Redis cache configuration
- 🔄 Automatic backups
- 📊 System monitoring
- 🛡️ Security hardening
- 📝 Log rotation
- 🚫 Fail2ban configuration
- 🔥 UFW firewall setup

## Prerequisites

- Ubuntu 20.04 or newer
- Root or sudo access
- Domain name pointed to your server

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/gfxguru/n8ndev.git
   cd n8ndev
   ```

2. Make scripts executable:
   ```bash
   chmod +x install/install.sh install/scripts/*.sh
   ```

3. Run the installation:
   ```bash
   cd install
   ./install.sh
   ```

## Configuration

The installation script will prompt you for:
- Domain name
- Email address (for SSL certificates)

Other configurations can be modified in `config/settings.env` before running the installation.

## Security

- UFW firewall enabled
- Fail2ban configured
- SSL certificates auto-renewal
- Regular security updates
- Secure database configuration
- Redis password protection

## Maintenance

- Daily backups at 2 AM
- Automatic log rotation
- SSL certificate auto-renewal
- System monitoring with alerts

## Directory Structure

```
/opt/n8n/
├── config/      # Configuration files
├── data/        # n8n data
├── logs/        # Application logs
└── scripts/     # Maintenance scripts

/opt/backups/
├── database/    # PostgreSQL backups
├── redis/       # Redis backups
└── n8n/         # n8n data backups
```

## License

MIT