#!/bin/bash
set -e

source ./config/settings.env

# Source modular components
source ./scripts/ssl/certbot.sh
source ./scripts/ssl/nginx-ssl.sh
source ./scripts/domain/nginx-domain.sh

echo "Setting up SSL and domain configuration..."

# Step 1: Configure initial HTTP-only setup for domain verification
configure_initial_nginx() {
    echo "Setting up initial HTTP configuration..."
    sudo tee /etc/nginx/sites-available/n8n << EOF
server {
    listen 80;
    listen [::]:80;
    server_name ${DOMAIN};
    
    location / {
        return 200 'Domain verification for SSL setup';
        add_header Content-Type text/plain;
    }
}
EOF
    sudo ln -sf /etc/nginx/sites-available/n8n /etc/nginx/sites-enabled/
    sudo rm -f /etc/nginx/sites-enabled/default
    sudo nginx -t && sudo systemctl reload nginx
}

# Step 2: Install SSL components
install_ssl_components() {
    echo "Installing SSL components..."
    install_certbot
    configure_nginx_ssl
}

# Step 3: Obtain SSL certificate
setup_ssl_certificate() {
    echo "Setting up SSL certificate..."
    obtain_ssl_certificate
}

# Step 4: Configure final Nginx setup
setup_final_nginx() {
    echo "Configuring final Nginx setup..."
    configure_nginx_domain
}

# Main execution
configure_initial_nginx
install_ssl_components
setup_ssl_certificate
setup_final_nginx

echo "SSL and domain configuration completed successfully!"