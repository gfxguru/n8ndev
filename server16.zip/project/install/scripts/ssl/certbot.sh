#!/bin/bash
set -e

source ./config/settings.env
source ./scripts/ssl/check-ssl.sh

install_certbot() {
    echo "Installing Certbot..."
    
    # Install Certbot and Nginx plugin
    sudo apt-get update
    sudo apt-get install -y \
        certbot \
        python3-certbot-nginx
}

obtain_ssl_certificate() {
    echo "Obtaining SSL certificate for ${DOMAIN}..."
    
    # Check if SSL is already installed
    if check_ssl_installed "${DOMAIN}"; then
        echo "SSL certificate already exists for ${DOMAIN}"
        return 0
    fi
    
    # Stop Nginx temporarily to free up port 80
    sudo systemctl stop nginx

    # Request certificate using standalone mode
    sudo certbot certonly \
        --standalone \
        --non-interactive \
        --agree-tos \
        --email "${EMAIL}" \
        --domains "${DOMAIN}" \
        --preferred-challenges http

    # Start Nginx again
    sudo systemctl start nginx

    # Verify certificate was obtained successfully
    if ! check_ssl_installed "${DOMAIN}"; then
        echo "Failed to obtain SSL certificate"
        exit 1
    fi

    # Enable auto-renewal
    sudo systemctl enable certbot.timer
    sudo systemctl start certbot.timer
}