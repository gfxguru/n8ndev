#!/bin/bash
set -e

source ./config/settings.env

setup_monitoring() {
    echo "Setting up monitoring..."
    
    # Install monitoring tools
    sudo apt-get install -y prometheus-node-exporter monit

    # Configure Monit
    sudo tee /etc/monit/conf.d/n8n << EOF
check process n8n matching "n8n"
    start program = "/bin/systemctl start n8n"
    stop program = "/bin/systemctl stop n8n"
    if failed port ${N8N_PORT} protocol http
        and request "/" with timeout 30 seconds
        then restart
    if 5 restarts within 5 cycles then timeout

check process postgresql matching "postgres"
    start program = "/bin/systemctl start postgresql"
    stop program = "/bin/systemctl stop postgresql"
    if failed host localhost port 5432 protocol pgsql
        then restart
    if 5 restarts within 5 cycles then timeout

check process redis matching "redis-server"
    start program = "/bin/systemctl start redis-server"
    stop program = "/bin/systemctl stop redis-server"
    if failed host 127.0.0.1 port ${REDIS_PORT}
        then restart
    if 5 restarts within 5 cycles then timeout

check system \$HOST
    if memory usage > 80% then alert
    if cpu usage > 90% for 5 cycles then alert
    if swap usage > 25% then alert
EOF

    # Restart Monit
    sudo systemctl restart monit
}

setup_monitoring