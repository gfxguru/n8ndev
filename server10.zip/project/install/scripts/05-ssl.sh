#!/bin/bash
set -e

source ./config/settings.env

setup_ssl() {
    echo "Setting up SSL with Let's Encrypt..."
    
    # Install Certbot
    sudo apt-get install -y certbot python3-certbot-nginx

    # Obtain SSL certificate
    sudo certbot --nginx \
        --non-interactive \
        --agree-tos \
        --email ${EMAIL} \
        --domains ${DOMAIN} \
        --redirect

    # Configure auto-renewal
    sudo systemctl enable certbot.timer
    sudo systemctl start certbot.timer
}

setup_ssl