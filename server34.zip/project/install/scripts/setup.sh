#!/bin/bash
set -e

# Get and validate configuration
setup_config() {
    while [[ -z "$DOMAIN" ]]; do
        read -p "Enter domain name: " domain
        if [[ $domain =~ ^[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9]\.[a-zA-Z]{2,}$ ]]; then
            sed -i "s/DOMAIN=.*/DOMAIN=\"$domain\"/" ./config/settings.env
        else
            echo "Invalid domain format"
        fi
    done

    while [[ -z "$EMAIL" ]]; do
        read -p "Enter email address: " email
        if [[ $email =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
            sed -i "s/EMAIL=.*/EMAIL=\"$email\"/" ./config/settings.env
        else
            echo "Invalid email format"
        fi
    done

    # Source the updated configuration
    source ./config/settings.env
}

setup_config