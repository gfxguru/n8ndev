#!/bin/bash
set -e

source ./config/settings.env

setup_n8n() {
    echo "Installing n8n..."
    
    # Install n8n globally
    sudo npm install -g n8n
    
    # Create n8n user
    sudo useradd -r -s /bin/false n8n || true
    
    # Create directories
    sudo mkdir -p /opt/n8n/{config,data}
    
    # Create environment file
    sudo tee /opt/n8n/config/.env << EOF
DB_TYPE=postgresdb
DB_POSTGRESDB_HOST=localhost
DB_POSTGRESDB_DATABASE=${POSTGRES_DB}
DB_POSTGRESDB_USER=${POSTGRES_USER}
DB_POSTGRESDB_PASSWORD=${POSTGRES_PASSWORD}
N8N_HOST=${DOMAIN}
N8N_PORT=${N8N_PORT}
N8N_PROTOCOL=https
EOF
    
    # Create systemd service
    sudo tee /etc/systemd/system/n8n.service << EOF
[Unit]
Description=n8n
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=n8n
EnvironmentFile=/opt/n8n/config/.env
ExecStart=/usr/bin/n8n start
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF
    
    # Set permissions
    sudo chown -R n8n:n8n /opt/n8n
    sudo chmod 600 /opt/n8n/config/.env
    
    # Enable and start service
    sudo systemctl enable n8n
    sudo systemctl start n8n
}

setup_n8n