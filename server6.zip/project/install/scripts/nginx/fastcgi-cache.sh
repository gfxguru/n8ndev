#!/bin/bash
set -e

source ./config/settings.env

configure_fastcgi_cache() {
    echo "Configuring FastCGI cache..."
    
    # Create cache directories
    sudo mkdir -p /var/cache/nginx/fastcgi
    sudo chown -R www-data:www-data /var/cache/nginx/fastcgi
    sudo chmod 700 /var/cache/nginx/fastcgi

    # Configure FastCGI cache settings
    sudo tee /etc/nginx/conf.d/fastcgi-cache.conf << EOF
# FastCGI cache settings
fastcgi_cache_path /var/cache/nginx/fastcgi 
    levels=1:2 
    keys_zone=n8n_cache:100m 
    inactive=60m 
    max_size=10g;
fastcgi_cache_key "\$request_method\$request_uri\$request_body";
fastcgi_cache_use_stale error timeout http_500 http_503;
fastcgi_cache_valid 200 60m;
fastcgi_cache_valid 404 1m;
fastcgi_cache_bypass \$http_pragma;
fastcgi_cache_revalidate on;
fastcgi_cache_background_update on;
fastcgi_cache_lock on;
EOF
}

configure_fastcgi_cache