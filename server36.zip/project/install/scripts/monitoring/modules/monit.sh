#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_monit_monitoring() {
    log_message "INFO" "Setting up Monit monitoring..."
    
    # Install Monit
    sudo apt-get install -y monit
    
    # Configure Monit for n8n
    sudo tee /etc/monit/conf.d/n8n << EOF
# n8n process monitoring
check process n8n matching "n8n"
    start program = "/bin/systemctl start n8n"
    stop program = "/bin/systemctl stop n8n"
    if failed port ${N8N_PORT} protocol http
        and request "/" with timeout 30 seconds
        then restart
    if 5 restarts within 5 cycles then timeout

# PostgreSQL monitoring
check process postgresql matching "postgres"
    start program = "/bin/systemctl start postgresql"
    stop program = "/bin/systemctl stop postgresql"
    if failed host localhost port 5432 protocol pgsql
        then restart
    if 5 restarts within 5 cycles then timeout

# System monitoring
check system \$HOST
    if memory usage > 80% then alert
    if cpu usage > 90% for 5 cycles then alert
    if swap usage > 25% then alert
EOF
    
    # Restart Monit
    sudo systemctl restart monit
}