#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_nginx_cache() {
    log_message "$LOG_INFO" "Setting up Nginx cache configuration..."
    
    # Create cache directories
    sudo mkdir -p /var/cache/nginx/{n8n,fastcgi}
    sudo chown -R www-data:www-data /var/cache/nginx
    sudo chmod 700 /var/cache/nginx/{n8n,fastcgi}
    
    # Copy cache configuration
    sudo cp ./scripts/nginx/conf.d/cache-paths.conf /etc/nginx/conf.d/
    
    # Verify configuration
    if sudo nginx -t; then
        log_message "$LOG_INFO" "Nginx cache configuration completed"
        sudo systemctl reload nginx
    else
        log_message "$LOG_ERROR" "Nginx configuration test failed"
        exit 1
    fi
}