#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_nginx() {
    log_message "INFO" "Setting up Nginx..."
    
    # Install Nginx
    sudo apt-get update
    sudo apt-get install -y nginx
    
    # Create required directories
    sudo mkdir -p /etc/nginx/conf.d
    sudo mkdir -p /var/cache/nginx/n8n
    sudo chown -R www-data:www-data /var/cache/nginx
    
    # Apply configurations
    source ./scripts/nginx/configs/apply-configs.sh
    apply_nginx_configs
    
    # Verify and restart
    if sudo nginx -t; then
        sudo systemctl restart nginx
        log_message "INFO" "Nginx setup completed successfully"
    else
        log_message "ERROR" "Nginx configuration test failed"
        exit 1
    fi
}