#!/bin/bash
set -e

source ./scripts/utils/logging.sh

apply_nginx_configs() {
    log_message "INFO" "Applying Nginx configurations..."
    
    # Copy configuration files
    sudo cp ./scripts/nginx/configs/conf.d/*.conf /etc/nginx/conf.d/
    
    # Remove default site if it exists
    sudo rm -f /etc/nginx/sites-enabled/default
    
    # Set proper permissions
    sudo chmod 644 /etc/nginx/conf.d/*.conf
}