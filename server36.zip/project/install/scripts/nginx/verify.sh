#!/bin/bash
set -e

source ./scripts/utils/logging.sh

verify_nginx() {
    log_message "INFO" "Verifying Nginx installation..."
    
    # Check if Nginx is installed
    if ! command -v nginx >/dev/null; then
        log_message "ERROR" "Nginx is not installed"
        return 1
    fi
    
    # Check if Nginx service is running
    if ! systemctl is-active --quiet nginx; then
        log_message "ERROR" "Nginx service is not running"
        return 1
    fi
    
    # Test Nginx configuration
    if ! nginx -t; then
        log_message "ERROR" "Nginx configuration test failed"
        return 1
    fi
    
    log_message "INFO" "Nginx verification completed successfully"
    return 0
}