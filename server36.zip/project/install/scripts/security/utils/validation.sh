#!/bin/bash
set -e

source ./scripts/utils/logging.sh

validate_security_requirements() {
    log_message "INFO" "Validating security requirements..."
    
    # Check required ports
    if [ -z "${N8N_PORT}" ]; then
        log_message "ERROR" "n8n port is not set"
        exit 1
    fi
    
    # Validate port number
    if ! [[ "${N8N_PORT}" =~ ^[0-9]+$ ]] || [ "${N8N_PORT}" -lt 1024 ] || [ "${N8N_PORT}" -gt 65535 ]; then
        log_message "ERROR" "Invalid port number: ${N8N_PORT}"
        exit 1
    fi
}