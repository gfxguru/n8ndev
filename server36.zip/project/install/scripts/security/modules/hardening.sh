#!/bin/bash
set -e

source ./scripts/utils/logging.sh

apply_system_hardening() {
    log_message "INFO" "Applying system hardening..."
    
    # Configure SSH hardening
    sudo tee /etc/ssh/sshd_config.d/hardening.conf << EOF
# SSH hardening configuration
PermitRootLogin no
PasswordAuthentication no
X11Forwarding no
MaxAuthTries 3
LoginGraceTime 20
EOF
    
    # Configure system-wide security limits
    sudo tee /etc/security/limits.d/security.conf << EOF
# System security limits
* soft nproc 1024
* hard nproc 2048
* soft nofile 8192
* hard nofile 16384
EOF
    
    # Configure sysctl security settings
    sudo tee /etc/sysctl.d/99-security.conf << EOF
# Network security settings
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.all.secure_redirects = 0
net.ipv4.conf.default.secure_redirects = 0
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.default.accept_source_route = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.conf.default.send_redirects = 0

# System security settings
kernel.sysrq = 0
kernel.core_uses_pid = 1
kernel.dmesg_restrict = 1
kernel.kptr_restrict = 2
kernel.unprivileged_bpf_disabled = 1
EOF
    
    # Apply sysctl settings
    sudo sysctl --system
    
    # Restart SSH service
    sudo systemctl restart ssh
    
    log_message "INFO" "System hardening completed"
}