#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_fail2ban() {
    log_message "INFO" "Setting up Fail2ban..."
    
    # Install fail2ban
    sudo apt-get install -y fail2ban
    
    # Create fail2ban configuration
    sudo tee /etc/fail2ban/jail.local << EOF
[DEFAULT]
bantime = 1h
findtime = 10m
maxretry = 5

[sshd]
enabled = true
port = ssh
filter = sshd
logpath = /var/log/auth.log
maxretry = 3

[nginx-http-auth]
enabled = true
filter = nginx-http-auth
port = http,https
logpath = /var/log/nginx/error.log

[nginx-botsearch]
enabled = true
filter = nginx-botsearch
port = http,https
logpath = /var/log/nginx/access.log
maxretry = 2
EOF
    
    # Create custom nginx filter for rate limiting
    sudo tee /etc/fail2ban/filter.d/nginx-req-limit.conf << EOF
[Definition]
failregex = limiting requests, excess:.* by zone.*client: <HOST>
ignoreregex =
EOF
    
    # Restart fail2ban
    sudo systemctl restart fail2ban
    
    # Verify fail2ban status
    if ! systemctl is-active --quiet fail2ban; then
        log_message "ERROR" "Failed to start fail2ban"
        exit 1
    fi
    
    log_message "INFO" "Fail2ban setup completed"
}