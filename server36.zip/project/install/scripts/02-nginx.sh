#!/bin/bash
set -e

# Install Nginx
apt-get update
apt-get install -y nginx

# Create configuration directory
mkdir -p /etc/nginx/conf.d

# Copy configuration
cp ./scripts/nginx/conf.d/nginx.conf /etc/nginx/nginx.conf

# Test and restart Nginx
if nginx -t; then
    systemctl restart nginx
else
    echo "Nginx configuration test failed!"
    exit 1
fi