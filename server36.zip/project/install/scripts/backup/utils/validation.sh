#!/bin/bash
set -e

source ./scripts/utils/logging.sh

validate_backup_requirements() {
    log_message "INFO" "Validating backup requirements..."
    
    # Check backup directory
    if [ -z "${BACKUP_DIR}" ]; then
        log_message "ERROR" "Backup directory is not set"
        exit 1
    fi
    
    # Check retention days
    if [ -z "${BACKUP_RETENTION_DAYS}" ]; then
        log_message "ERROR" "Backup retention days is not set"
        exit 1
    fi
    
    # Validate retention days
    if ! [[ "${BACKUP_RETENTION_DAYS}" =~ ^[0-9]+$ ]] || [ "${BACKUP_RETENTION_DAYS}" -lt 1 ]; then
        log_message "ERROR" "Invalid backup retention days: ${BACKUP_RETENTION_DAYS}"
        exit 1
    fi
}