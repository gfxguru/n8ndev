#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_backup_rotation() {
    log_message "INFO" "Setting up backup rotation..."
    
    # Create rotation script
    sudo tee "${N8N_DIR}/scripts/rotate-backups.sh" << 'EOF'
#!/bin/bash
set -e

# Remove old database backups
find "${BACKUP_DIR}/database" -type f -mtime +${BACKUP_RETENTION_DAYS} -delete

# Remove old file backups
find "${BACKUP_DIR}/n8n" -type f -mtime +${BACKUP_RETENTION_DAYS} -delete

# Log rotation
echo "$(date): Backup rotation completed" >> "${N8N_DIR}/logs/backup.log"
EOF
    
    # Set permissions
    sudo chmod +x "${N8N_DIR}/scripts/rotate-backups.sh"
    sudo chown n8n:n8n "${N8N_DIR}/scripts/rotate-backups.sh"
    
    # Setup cron job
    sudo tee /etc/cron.d/n8n-backup << EOF
# Run backups daily at 2 AM
0 2 * * * n8n ${N8N_DIR}/scripts/backup-db.sh
15 2 * * * n8n ${N8N_DIR}/scripts/backup-files.sh
30 2 * * * n8n ${N8N_DIR}/scripts/rotate-backups.sh
EOF
    
    # Set proper permissions for cron job
    sudo chmod 644 /etc/cron.d/n8n-backup
}