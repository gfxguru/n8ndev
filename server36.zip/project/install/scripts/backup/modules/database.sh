#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_database_backup() {
    log_message "INFO" "Setting up database backup..."
    
    # Create backup script
    sudo tee "${N8N_DIR}/scripts/backup-db.sh" << 'EOF'
#!/bin/bash
set -e

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="${BACKUP_DIR}/database/n8n_db_${TIMESTAMP}.sql.gz"

# Create backup directory if it doesn't exist
mkdir -p "${BACKUP_DIR}/database"

# Perform backup
PGPASSWORD="${POSTGRES_PASSWORD}" pg_dump \
    -h localhost \
    -U "${POSTGRES_USER}" \
    "${POSTGRES_DB}" | gzip > "${BACKUP_FILE}"

# Log backup completion
echo "$(date): Database backup completed: ${BACKUP_FILE}" >> "${N8N_DIR}/logs/backup.log"
EOF
    
    # Set permissions
    sudo chmod +x "${N8N_DIR}/scripts/backup-db.sh"
    sudo chown n8n:n8n "${N8N_DIR}/scripts/backup-db.sh"
}