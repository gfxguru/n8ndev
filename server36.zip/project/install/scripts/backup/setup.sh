#!/bin/bash
set -e

source ./scripts/utils/logging.sh
source ./scripts/backup/utils/validation.sh
source ./scripts/backup/modules/database.sh
source ./scripts/backup/modules/files.sh
source ./scripts/backup/modules/rotation.sh

setup_backup() {
    log_message "INFO" "Setting up backup system..."
    
    # Validate requirements
    validate_backup_requirements
    
    # Setup database backups
    setup_database_backup
    
    # Setup file backups
    setup_file_backup
    
    # Setup backup rotation
    setup_backup_rotation
    
    log_message "INFO" "Backup system setup completed"
}