#!/bin/bash
set -e

source ./config/settings.env

setup_ssl() {
    echo "Setting up SSL..."
    
    # Install Certbot (Ubuntu 24.04 uses snap)
    sudo snap install --classic certbot
    sudo ln -sf /snap/bin/certbot /usr/bin/certbot
    
    # Stop Nginx temporarily
    sudo systemctl stop nginx
    
    # Get certificate
    sudo certbot certonly \
        --standalone \
        --non-interactive \
        --agree-tos \
        --email "${EMAIL}" \
        --domains "${DOMAIN}"
    
    # Start Nginx
    sudo systemctl start nginx
    
    # Setup auto-renewal
    sudo snap set certbot trust-plugin-with-root=ok
    sudo systemctl enable snap.certbot.renew.timer
    sudo systemctl start snap.certbot.renew.timer
}

setup_ssl