#!/bin/bash
set -e

source ./config/settings.env

# Install Certbot
apt-get install -y certbot python3-certbot-nginx

# Stop Nginx temporarily
systemctl stop nginx

# Get SSL certificate
certbot certonly \
    --standalone \
    --non-interactive \
    --agree-tos \
    --email "${EMAIL}" \
    --domains "${DOMAIN}"

# Start Nginx
systemctl start nginx

# Enable auto-renewal
systemctl enable certbot.timer
systemctl start certbot.timer