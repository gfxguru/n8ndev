#!/bin/bash
set -e

source ./scripts/utils/logging.sh
source ./scripts/ssl/utils/validation.sh
source ./scripts/ssl/utils/certbot.sh
source ./scripts/ssl/modules/install.sh
source ./scripts/ssl/modules/configure.sh
source ./scripts/ssl/modules/renewal.sh

setup_ssl() {
    log_message "INFO" "Starting SSL setup..."
    
    # Validate requirements
    validate_ssl_requirements
    
    # Install SSL components
    install_ssl_components
    
    # Configure SSL
    configure_ssl
    
    # Setup auto-renewal
    setup_ssl_renewal
    
    log_message "INFO" "SSL setup completed successfully"
}