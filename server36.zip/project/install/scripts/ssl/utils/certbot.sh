#!/bin/bash
set -e

source ./scripts/utils/logging.sh

install_certbot() {
    log_message "INFO" "Installing Certbot..."
    
    # Install Certbot via snap (recommended for Ubuntu 24.04)
    if ! command -v snap &> /dev/null; then
        sudo apt-get update
        sudo apt-get install -y snapd
    fi
    
    sudo snap install --classic certbot
    sudo ln -sf /snap/bin/certbot /usr/bin/certbot
}

verify_certbot() {
    if ! command -v certbot &> /dev/null; then
        log_message "ERROR" "Certbot installation failed"
        return 1
    fi
    
    local version=$(certbot --version)
    log_message "INFO" "Certbot ${version} installed successfully"
    return 0
}