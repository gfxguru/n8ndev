#!/bin/bash
set -e

source ./scripts/utils/logging.sh

verify_ssl_certificate() {
    local domain="$1"
    log_message "INFO" "Verifying SSL certificate for ${domain}..."
    
    # Check certificate existence
    if [ ! -f "/etc/letsencrypt/live/${domain}/fullchain.pem" ]; then
        log_message "ERROR" "SSL certificate not found"
        return 1
    fi
    
    # Verify certificate validity
    if ! openssl x509 -in "/etc/letsencrypt/live/${domain}/fullchain.pem" -noout -checkend 0; then
        log_message "ERROR" "SSL certificate has expired"
        return 1
    fi
    
    # Check private key
    if [ ! -f "/etc/letsencrypt/live/${domain}/privkey.pem" ]; then
        log_message "ERROR" "SSL private key not found"
        return 1
    fi
    
    log_message "INFO" "SSL certificate verification completed successfully"
    return 0
}