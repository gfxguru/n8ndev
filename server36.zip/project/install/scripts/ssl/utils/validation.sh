#!/bin/bash
set -e

source ./scripts/utils/logging.sh

validate_ssl_requirements() {
    log_message "INFO" "Validating SSL requirements..."
    
    # Check domain
    if [ -z "${DOMAIN}" ]; then
        log_message "ERROR" "Domain is not set"
        exit 1
    fi
    
    # Check email
    if [ -z "${EMAIL}" ]; then
        log_message "ERROR" "Email is not set"
        exit 1
    fi
    
    # Validate domain format
    if ! [[ "${DOMAIN}" =~ ^[a-zA-Z0-9][a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
        log_message "ERROR" "Invalid domain format: ${DOMAIN}"
        exit 1
    fi
    
    # Validate email format
    if ! [[ "${EMAIL}" =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
        log_message "ERROR" "Invalid email format: ${EMAIL}"
        exit 1
    fi
}