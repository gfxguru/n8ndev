#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_ssl_renewal() {
    log_message "INFO" "Setting up SSL auto-renewal..."
    
    # Configure Certbot renewal hook
    sudo mkdir -p /etc/letsencrypt/renewal-hooks/deploy
    
    # Create Nginx reload hook
    sudo tee /etc/letsencrypt/renewal-hooks/deploy/nginx-reload << EOF
#!/bin/bash
systemctl reload nginx
EOF
    
    sudo chmod +x /etc/letsencrypt/renewal-hooks/deploy/nginx-reload
    
    # Enable and start renewal timer
    sudo systemctl enable snap.certbot.renew.timer
    sudo systemctl start snap.certbot.renew.timer
    
    # Verify timer status
    if ! systemctl is-active --quiet snap.certbot.renew.timer; then
        log_message "ERROR" "Failed to enable SSL auto-renewal"
        exit 1
    fi
}