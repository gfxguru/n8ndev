#!/bin/bash

# Log levels
LOG_INFO="INFO"
LOG_WARNING="WARNING"
LOG_ERROR="ERROR"

# Logging function
log_message() {
    local level="$1"
    local message="$2"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$timestamp] $level: $message"
}