#!/bin/bash
set -e

check_ubuntu_version() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        if [ "${VERSION_ID}" != "24.04" ]; then
            echo "This script requires Ubuntu 24.04"
            exit 1
        fi
    else
        echo "Cannot determine OS version"
        exit 1
    fi
}