#!/bin/bash
set -e

source ./scripts/utils/logging.sh

configure_n8n() {
    log_message "INFO" "Configuring n8n..."
    
    # Create environment configuration
    sudo tee "${N8N_DIR}/config/.env" << EOF
# Database Configuration
DB_TYPE=postgresdb
DB_POSTGRESDB_HOST=localhost
DB_POSTGRESDB_DATABASE=${POSTGRES_DB}
DB_POSTGRESDB_USER=${POSTGRES_USER}
DB_POSTGRESDB_PASSWORD=${POSTGRES_PASSWORD}

# Server Configuration
N8N_HOST=${DOMAIN}
N8N_PORT=${N8N_PORT}
N8N_PROTOCOL=https
N8N_USER_FOLDER="${N8N_DIR}/data"
N8N_LOG_LEVEL=info
N8N_LOG_OUTPUT="${N8N_DIR}/logs/n8n.log"

# Security Configuration
N8N_ENCRYPTION_KEY="$(openssl rand -hex 24)"
NODE_ENV=production

# Performance Settings
NODE_OPTIONS="--max-old-space-size=4096"

# Execution Settings
EXECUTIONS_DATA_PRUNE=true
EXECUTIONS_DATA_MAX_AGE=168
EXECUTIONS_DATA_PRUNE_TIMEOUT=7200

# Timezone
GENERIC_TIMEZONE="UTC"
EOF
    
    # Set proper permissions for environment file
    sudo chown n8n:n8n "${N8N_DIR}/config/.env"
    sudo chmod 600 "${N8N_DIR}/config/.env"
    
    log_message "INFO" "n8n configuration completed"
}