#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_n8n_service() {
    log_message "INFO" "Setting up n8n service..."
    
    # Create systemd service
    sudo tee /etc/systemd/system/n8n.service << EOF
[Unit]
Description=n8n Workflow Automation
After=network.target postgresql.service
Wants=postgresql.service

[Service]
Type=simple
User=n8n
Group=n8n
EnvironmentFile=${N8N_DIR}/config/.env
ExecStart=/usr/bin/n8n start
Restart=always
RestartSec=10
WorkingDirectory=${N8N_DIR}
StandardOutput=append:${N8N_DIR}/logs/n8n-output.log
StandardError=append:${N8N_DIR}/logs/n8n-error.log

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=true
ReadOnlyDirectories=/
ReadWriteDirectories=${N8N_DIR}

[Install]
WantedBy=multi-user.target
EOF
    
    # Reload systemd and start n8n
    sudo systemctl daemon-reload
    sudo systemctl enable n8n
    sudo systemctl start n8n
    
    # Verify service status
    if ! systemctl is-active --quiet n8n; then
        log_message "ERROR" "n8n service failed to start"
        exit 1
    fi
    
    log_message "INFO" "n8n service setup completed"
}