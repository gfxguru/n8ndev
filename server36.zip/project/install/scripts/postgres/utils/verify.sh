#!/bin/bash
set -e

source ./scripts/utils/logging.sh

verify_postgres_connection() {
    log_message "INFO" "Verifying PostgreSQL connection..."
    
    # Test connection
    if ! PGPASSWORD="${POSTGRES_PASSWORD}" psql \
        -h localhost \
        -U "${POSTGRES_USER}" \
        -d "${POSTGRES_DB}" \
        -c '\q' 2>/dev/null; then
        log_message "ERROR" "Unable to connect to PostgreSQL"
        return 1
    fi
    
    log_message "INFO" "PostgreSQL connection verified"
    return 0
}

verify_postgres_service() {
    log_message "INFO" "Verifying PostgreSQL service..."
    
    # Check if service is running
    if ! systemctl is-active --quiet postgresql; then
        log_message "ERROR" "PostgreSQL service is not running"
        return 1
    fi
    
    log_message "INFO" "PostgreSQL service is running"
    return 0
}