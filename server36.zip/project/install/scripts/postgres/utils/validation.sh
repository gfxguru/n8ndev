#!/bin/bash
set -e

source ./scripts/utils/logging.sh

validate_postgres_requirements() {
    log_message "INFO" "Validating PostgreSQL requirements..."
    
    # Check PostgreSQL version
    if [ -z "${POSTGRES_VERSION}" ]; then
        log_message "ERROR" "PostgreSQL version is not set"
        exit 1
    fi
    
    # Check database name
    if [ -z "${POSTGRES_DB}" ]; then
        log_message "ERROR" "Database name is not set"
        exit 1
    fi
    
    # Check database user
    if [ -z "${POSTGRES_USER}" ]; then
        log_message "ERROR" "Database user is not set"
        exit 1
    fi
    
    # Check database password
    if [ -z "${POSTGRES_PASSWORD}" ]; then
        log_message "ERROR" "Database password is not set"
        exit 1
    fi
}