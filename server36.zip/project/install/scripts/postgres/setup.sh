#!/bin/bash
set -e

source ./scripts/utils/logging.sh
source ./scripts/postgres/utils/validation.sh
source ./scripts/postgres/modules/install.sh
source ./scripts/postgres/modules/configure.sh
source ./scripts/postgres/modules/security.sh

setup_postgres() {
    log_message "INFO" "Starting PostgreSQL setup..."
    
    # Validate requirements
    validate_postgres_requirements
    
    # Install PostgreSQL
    install_postgres_components
    
    # Configure PostgreSQL
    configure_postgres
    
    # Apply security settings
    secure_postgres
    
    log_message "INFO" "PostgreSQL setup completed successfully"
}