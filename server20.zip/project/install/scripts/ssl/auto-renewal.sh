#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_auto_renewal() {
    log_message "$LOG_INFO" "Setting up SSL certificate auto-renewal..."
    
    # Configure auto-renewal based on Ubuntu version
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        if [[ "${VERSION_ID}" == "24.04" ]]; then
            sudo snap set certbot trust-plugin-with-root=ok
        fi
    fi
    
    # Enable and start certbot timer
    sudo systemctl enable certbot.timer
    sudo systemctl start certbot.timer
    
    # Create renewal hook directory
    sudo mkdir -p /etc/letsencrypt/renewal-hooks/post
    
    # Create post-renewal hook to restart Nginx
    sudo tee /etc/letsencrypt/renewal-hooks/post/nginx-reload << EOF
#!/bin/bash
systemctl reload nginx
EOF
    
    sudo chmod +x /etc/letsencrypt/renewal-hooks/post/nginx-reload
    
    log_message "$LOG_INFO" "Auto-renewal configured successfully"
}