#!/bin/bash
set -e

source ./config/settings.env
source ./scripts/utils/logging.sh
source ./scripts/ssl/check-ssl.sh
source ./scripts/ssl/certbot-utils.sh

install_certbot() {
    log_message "$LOG_INFO" "Installing Certbot..."
    
    # Check Ubuntu version for installation method
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        if [[ "${VERSION_ID}" == "24.04" ]]; then
            # Ubuntu 24.04 uses snap for certbot
            sudo snap install --classic certbot
            sudo ln -sf /snap/bin/certbot /usr/bin/certbot
        else
            # Older versions use apt
            sudo apt-get update
            sudo apt-get install -y certbot python3-certbot-nginx
        fi
    fi

    # Verify installation
    if ! verify_certbot_installation; then
        log_message "$LOG_ERROR" "Failed to install Certbot"
        exit 1
    fi
}

obtain_ssl_certificate() {
    log_message "$LOG_INFO" "Obtaining SSL certificate for ${DOMAIN}..."
    
    if check_ssl_installed "${DOMAIN}"; then
        log_message "$LOG_INFO" "SSL certificate already exists for ${DOMAIN}"
        return 0
    fi
    
    # Stop Nginx temporarily
    sudo systemctl stop nginx

    # Request certificate
    if ! sudo certbot certonly \
        --standalone \
        --non-interactive \
        --agree-tos \
        --email "${EMAIL}" \
        --domains "${DOMAIN}" \
        --preferred-challenges http; then
        
        log_message "$LOG_ERROR" "Failed to obtain SSL certificate"
        sudo systemctl start nginx
        exit 1
    fi

    # Start Nginx again
    sudo systemctl start nginx

    # Verify certificate
    if ! check_ssl_installed "${DOMAIN}"; then
        log_message "$LOG_ERROR" "SSL certificate verification failed"
        exit 1
    fi

    # Configure auto-renewal
    if [[ "${VERSION_ID}" == "24.04" ]]; then
        sudo snap set certbot trust-plugin-with-root=ok
    fi
    
    sudo systemctl enable certbot.timer
    sudo systemctl start certbot.timer
}