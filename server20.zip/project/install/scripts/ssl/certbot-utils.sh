#!/bin/bash
set -e

source ./scripts/utils/logging.sh

install_certbot() {
    log_message "$LOG_INFO" "Installing Certbot..."
    
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        if [[ "${VERSION_ID}" == "24.04" ]]; then
            sudo snap install --classic certbot
            sudo ln -sf /snap/bin/certbot /usr/bin/certbot
        else
            sudo apt-get update
            sudo apt-get install -y certbot python3-certbot-nginx
        fi
    fi
}

verify_certbot_installation() {
    if ! command -v certbot >/dev/null 2>&1; then
        log_message "$LOG_ERROR" "Certbot is not installed"
        return 1
    fi
    return 0
}