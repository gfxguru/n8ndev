#!/bin/bash
set -e

source ./config/settings.env
source ./scripts/utils/logging.sh
source ./scripts/ssl/check-ssl.sh
source ./scripts/ssl/certbot-utils.sh
source ./scripts/ssl/dhparam-utils.sh
source ./scripts/ssl/auto-renewal.sh

setup_ssl() {
    log_message "$LOG_INFO" "Starting SSL setup for ${DOMAIN}..."
    
    # Step 1: Install Certbot
    if ! verify_certbot_installation; then
        install_certbot
    fi
    
    # Step 2: Stop Nginx if running
    if systemctl is-active --quiet nginx; then
        log_message "$LOG_INFO" "Stopping Nginx temporarily..."
        sudo systemctl stop nginx
    fi
    
    # Step 3: Obtain certificate
    if ! check_ssl_installed "${DOMAIN}"; then
        log_message "$LOG_INFO" "Obtaining new SSL certificate..."
        if ! sudo certbot certonly \
            --standalone \
            --non-interactive \
            --agree-tos \
            --email "${EMAIL}" \
            --domains "${DOMAIN}" \
            --preferred-challenges http; then
            
            log_message "$LOG_ERROR" "Failed to obtain SSL certificate"
            sudo systemctl start nginx
            exit 1
        fi
    fi
    
    # Step 4: Verify certificate
    if ! check_ssl_installed "${DOMAIN}"; then
        log_message "$LOG_ERROR" "SSL certificate verification failed"
        exit 1
    fi
    
    # Step 5: Generate DH parameters
    generate_dhparam
    
    # Step 6: Configure auto-renewal
    setup_auto_renewal
    
    log_message "$LOG_INFO" "SSL setup completed successfully"
    return 0
}