#!/bin/bash
set -e

source ./config/settings.env

echo "Setting up SSL and domain configuration..."

# Step 1: Configure initial Nginx without SSL
sudo tee /etc/nginx/sites-available/n8n << EOF
server {
    listen 80;
    listen [::]:80;
    server_name ${DOMAIN};

    location / {
        proxy_pass http://127.0.0.1:${N8N_PORT};
        proxy_http_version 1.1;
        include /etc/nginx/conf.d/proxy-params.conf;
    }
}
EOF

# Enable the site
sudo ln -sf /etc/nginx/sites-available/n8n /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default

# Test and start Nginx
sudo nginx -t && sudo systemctl restart nginx

# Step 2: Install and run Certbot
echo "Installing Certbot..."
sudo apt-get update
sudo apt-get install -y certbot python3-certbot-nginx

# Obtain certificate
echo "Obtaining SSL certificate for ${DOMAIN}..."
sudo certbot --nginx \
    --non-interactive \
    --agree-tos \
    --email "${EMAIL}" \
    --domains "${DOMAIN}" \
    --redirect

# Step 3: Configure SSL parameters
echo "Configuring SSL parameters..."
sudo mkdir -p /etc/nginx/ssl
sudo openssl dhparam -out /etc/nginx/ssl/dhparam.pem 2048

sudo tee /etc/nginx/conf.d/ssl-params.conf << EOF
# SSL parameters
ssl_protocols TLSv1.2 TLSv1.3;
ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384;
ssl_prefer_server_ciphers off;
ssl_dhparam /etc/nginx/ssl/dhparam.pem;

# Session settings
ssl_session_timeout 1d;
ssl_session_cache shared:SSL:50m;
ssl_session_tickets off;

# OCSP Stapling
ssl_stapling on;
ssl_stapling_verify on;
resolver 8.8.8.8 8.8.4.4 valid=300s;
resolver_timeout 5s;

# HSTS
add_header Strict-Transport-Security "max-age=63072000" always;
EOF

# Step 4: Configure final Nginx setup with SSL
sudo tee /etc/nginx/sites-available/n8n << EOF
# HTTP - redirect all requests to HTTPS
server {
    listen 80;
    listen [::]:80;
    server_name ${DOMAIN};
    return 301 https://\$server_name\$request_uri;
}

# HTTPS - proxy requests to n8n
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name ${DOMAIN};

    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/${DOMAIN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${DOMAIN}/privkey.pem;
    include /etc/nginx/conf.d/ssl-params.conf;
    
    location / {
        proxy_pass http://127.0.0.1:${N8N_PORT};
        proxy_http_version 1.1;
        include /etc/nginx/conf.d/proxy-params.conf;
        include /etc/nginx/conf.d/security-headers.conf;
    }
}
EOF

# Step 5: Configure n8n domain settings
echo "Configuring n8n domain settings..."
sudo mkdir -p ${N8N_DIR}/config
sudo tee ${N8N_DIR}/config/domain.env << EOF
# Domain Configuration
N8N_HOST="${DOMAIN}"
N8N_PROTOCOL="https"
N8N_PORT=${N8N_PORT}
N8N_EDITOR_BASE_URL="https://${DOMAIN}"

# Security Settings
N8N_ENCRYPTION_KEY="$(openssl rand -hex 24)"
N8N_BASIC_AUTH_ACTIVE=true

# CORS Settings
N8N_CORS_ENABLE=true
N8N_CORS_ALLOWED_ORIGINS="https://${DOMAIN}"
EOF

# Set proper permissions
sudo chown -R n8n:n8n ${N8N_DIR}/config
sudo chmod 640 ${N8N_DIR}/config/domain.env

# Final Nginx test and restart
if sudo nginx -t; then
    echo "Nginx configuration test passed. Restarting Nginx..."
    sudo systemctl restart nginx
else
    echo "Nginx configuration test failed. Please check the configuration."
    exit 1
fi

echo "SSL and domain configuration completed successfully!"