#!/bin/bash
set -e

source ./config/settings.env

setup_nginx() {
    echo "Setting up Nginx..."
    
    # Install Nginx
    sudo apt-get install -y nginx

    # Create required directories
    sudo mkdir -p /etc/nginx/conf.d
    sudo mkdir -p /var/cache/nginx/n8n
    sudo chown -R www-data:www-data /var/cache/nginx/n8n
    sudo chmod 700 /var/cache/nginx/n8n

    # Create base configuration files
    sudo tee /etc/nginx/conf.d/proxy-params.conf << EOF
proxy_set_header Host \$host;
proxy_set_header X-Real-IP \$remote_addr;
proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto \$scheme;
proxy_set_header Upgrade \$http_upgrade;
proxy_set_header Connection "upgrade";
proxy_connect_timeout 180s;
proxy_send_timeout 180s;
proxy_read_timeout 180s;
proxy_buffer_size 128k;
proxy_buffers 4 256k;
proxy_busy_buffers_size 256k;
client_max_body_size 100M;
EOF

    sudo tee /etc/nginx/conf.d/security-headers.conf << EOF
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "no-referrer-when-downgrade" always;
add_header Content-Security-Policy "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob:; img-src 'self' data: blob:;" always;
EOF

    # Create n8n site configuration
    sudo tee /etc/nginx/sites-available/n8n << EOF
# HTTP - redirect all requests to HTTPS
server {
    listen 80;
    listen [::]:80;
    server_name ${DOMAIN};
    return 301 https://\$server_name\$request_uri;
}

# HTTPS - proxy requests to n8n
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name ${DOMAIN};

    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/${DOMAIN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${DOMAIN}/privkey.pem;
    
    # Basic SSL settings
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers off;
    ssl_session_timeout 1d;
    ssl_session_cache shared:SSL:50m;
    ssl_session_tickets off;
    
    location / {
        proxy_pass http://127.0.0.1:${N8N_PORT};
        proxy_http_version 1.1;
        include /etc/nginx/conf.d/proxy-params.conf;
        include /etc/nginx/conf.d/security-headers.conf;
    }
}
EOF

    # Enable n8n site and remove default
    sudo rm -f /etc/nginx/sites-enabled/default
    sudo ln -sf /etc/nginx/sites-available/n8n /etc/nginx/sites-enabled/

    # Test configuration
    if sudo nginx -t; then
        echo "Nginx configuration test passed. Starting Nginx..."
        sudo systemctl restart nginx
    else
        echo "Nginx configuration test failed!"
        exit 1
    fi
}

setup_nginx