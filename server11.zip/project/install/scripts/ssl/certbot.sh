#!/bin/bash
set -e

source ./config/settings.env

install_certbot() {
    echo "Installing Certbot..."
    
    # Install Certbot and Nginx plugin
    sudo apt-get update
    sudo apt-get install -y \
        certbot \
        python3-certbot-nginx
}

obtain_ssl_certificate() {
    echo "Obtaining SSL certificate for ${DOMAIN}..."
    
    # Request certificate
    sudo certbot --nginx \
        --non-interactive \
        --agree-tos \
        --email "${EMAIL}" \
        --domains "${DOMAIN}" \
        --redirect

    # Enable auto-renewal
    sudo systemctl enable certbot.timer
    sudo systemctl start certbot.timer
}

# Main execution
install_certbot
obtain_ssl_certificate