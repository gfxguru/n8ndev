#!/bin/bash
set -e

source ./config/settings.env

setup_nodejs() {
    echo "Setting up Node.js..."
    
    # Install Node.js
    curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | sudo -E bash -
    sudo apt-get install -y nodejs

    # Install PM2 globally
    sudo npm install -g pm2

    # Configure PM2 startup
    sudo pm2 startup systemd
}

setup_nodejs