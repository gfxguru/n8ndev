#!/bin/bash
set -e

source ./config/settings.env
source ./scripts/utils/logging.sh
source ./scripts/ssl/check-ssl.sh

setup_nginx_ssl() {
    log_message "$LOG_INFO" "Setting up Nginx SSL configuration..."
    
    # Verify SSL certificate exists before proceeding
    if ! check_ssl_installed "${DOMAIN}"; then
        log_message "$LOG_ERROR" "SSL certificate must be installed before configuring Nginx"
        exit 1
    fi
    
    # Create SSL directory if it doesn't exist
    sudo mkdir -p /etc/nginx/ssl
    
    # Copy SSL configuration files
    local conf_dir="/etc/nginx/conf.d"
    for conf in ssl-{ciphers,session,stapling,hsts,params}.conf; do
        sudo cp "./scripts/nginx/conf.d/$conf" "$conf_dir/"
        sudo chmod 644 "$conf_dir/$conf"
    done
    
    log_message "$LOG_INFO" "Nginx SSL configuration completed"
}