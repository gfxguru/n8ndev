#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_nginx_cache() {
    log_message "$LOG_INFO" "Setting up Nginx cache configuration..."
    
    # Create cache directories
    sudo mkdir -p /var/cache/nginx/{n8n,fastcgi}
    sudo chown -R www-data:www-data /var/cache/nginx
    sudo chmod 700 /var/cache/nginx/{n8n,fastcgi}
    
    # Ensure cache paths are included in main nginx.conf
    local nginx_conf="/etc/nginx/nginx.conf"
    if ! grep -q "include /etc/nginx/conf.d/cache-paths.conf;" "$nginx_conf"; then
        # Add include directive in http context
        sudo sed -i '/^http {/a \    include /etc/nginx/conf.d/cache-paths.conf;' "$nginx_conf"
    fi
    
    log_message "$LOG_INFO" "Nginx cache configuration completed"
}