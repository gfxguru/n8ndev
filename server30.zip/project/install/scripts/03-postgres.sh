#!/bin/bash
set -e

source ./config/settings.env

setup_postgres() {
    echo "Setting up PostgreSQL..."
    
    # Add PostgreSQL repository
    sudo sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt $(lsb_release -cs)-pgdg main" > /etc/apt/sources.list.d/pgdg.list'
    wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | sudo apt-key add -
    sudo apt-get update

    # Install PostgreSQL
    sudo apt-get install -y postgresql-${POSTGRES_VERSION} postgresql-contrib

    # Configure PostgreSQL
    sudo -u postgres psql -c "CREATE USER ${POSTGRES_USER} WITH PASSWORD '${POSTGRES_PASSWORD}';"
    sudo -u postgres psql -c "CREATE DATABASE ${POSTGRES_DB} OWNER ${POSTGRES_USER};"
    
    # Configure PostgreSQL settings
    sudo tee /etc/postgresql/${POSTGRES_VERSION}/main/conf.d/n8n_optimizations.conf << EOF
shared_buffers = 256MB
work_mem = 16MB
maintenance_work_mem = 128MB
effective_cache_size = 1GB
max_connections = 100
EOF

    # Restart PostgreSQL
    sudo systemctl restart postgresql
}

setup_postgres