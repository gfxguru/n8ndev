#!/bin/bash
set -e

source ./config/settings.env
source ./scripts/utils/logging.sh

setup_ssl() {
    log_message "$LOG_INFO" "Setting up SSL for ${DOMAIN}..."
    
    # Install Certbot
    if ! command -v certbot >/dev/null 2>&1; then
        sudo apt-get update
        sudo apt-get install -y certbot python3-certbot-nginx
    fi
    
    # Stop Nginx temporarily
    sudo systemctl stop nginx
    
    # Obtain certificate
    sudo certbot certonly \
        --standalone \
        --non-interactive \
        --agree-tos \
        --email "${EMAIL}" \
        --domains "${DOMAIN}" \
        --preferred-challenges http
    
    # Generate DH parameters if needed
    if [ ! -f /etc/nginx/ssl/dhparam.pem ]; then
        sudo mkdir -p /etc/nginx/ssl
        sudo openssl dhparam -out /etc/nginx/ssl/dhparam.pem 2048
    fi
    
    # Configure auto-renewal
    sudo systemctl enable certbot.timer
    sudo systemctl start certbot.timer
    
    log_message "$LOG_INFO" "SSL setup completed"
}