#!/bin/bash
set -e

source ./config/settings.env

setup_nginx() {
    echo "Setting up Nginx..."
    
    # Install Nginx
    sudo apt-get install -y nginx

    # Create required directories
    sudo mkdir -p /etc/nginx/conf.d
    sudo mkdir -p /var/cache/nginx/n8n
    sudo chown -R www-data:www-data /var/cache/nginx/n8n
    sudo chmod 700 /var/cache/nginx/n8n

    # Generate SSL parameters
    sudo mkdir -p /etc/nginx/ssl
    sudo openssl dhparam -out /etc/nginx/ssl/dhparam.pem 2048

    # Copy configuration files
    sudo cp ./scripts/nginx/conf.d/*.conf /etc/nginx/conf.d/

    # Create basic site configuration
    sudo tee /etc/nginx/sites-available/n8n << EOF
# HTTP - redirect all requests to HTTPS
server {
    listen 80;
    listen [::]:80;
    server_name ${DOMAIN};
    return 301 https://\$server_name\$request_uri;
}

# HTTPS - proxy requests to n8n
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name ${DOMAIN};

    # SSL Configuration
    ssl_certificate /etc/letsencrypt/live/${DOMAIN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${DOMAIN}/privkey.pem;
    ssl_dhparam /etc/nginx/ssl/dhparam.pem;
    include /etc/nginx/conf.d/ssl-params.conf;
    
    location / {
        proxy_pass http://127.0.0.1:${N8N_PORT};
        proxy_http_version 1.1;
        include /etc/nginx/conf.d/proxy-params.conf;
        
        # Cache settings
        include /etc/nginx/conf.d/proxy-cache.conf;
    }
    
    # Security headers
    include /etc/nginx/conf.d/security-headers.conf;
}
EOF

    # Enable n8n site and remove default
    sudo rm -f /etc/nginx/sites-enabled/default
    sudo ln -sf /etc/nginx/sites-available/n8n /etc/nginx/sites-enabled/

    # Test configuration
    if sudo nginx -t; then
        echo "Nginx configuration test passed. Starting Nginx..."
        sudo systemctl restart nginx
    else
        echo "Nginx configuration test failed!"
        exit 1
    fi
}

setup_nginx