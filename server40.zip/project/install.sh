#!/bin/bash
set -e

# Source configuration
source ./config/settings.env

# Make scripts executable
chmod +x ./scripts/*.sh

# Run installation steps
./scripts/setup.sh      # Get domain and email configuration
./scripts/nodejs.sh     # Install Node.js
./scripts/postgres.sh   # Install PostgreSQL
./scripts/n8n.sh       # Install n8n
./scripts/nginx.sh      # Install and configure Nginx
./scripts/ssl.sh       # Configure SSL with Let's Encrypt

echo "Installation completed successfully!"
echo "n8n is available at https://${DOMAIN}"