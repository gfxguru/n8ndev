#!/bin/bash
set -e

source ./config/settings.env

echo "Installing Node.js ${NODE_VERSION}..."

# Add NodeSource repository
curl -fsSL "https://deb.nodesource.com/setup_${NODE_VERSION}.x" | sudo -E bash -

# Install Node.js
sudo apt-get install -y nodejs

# Verify installation
node --version
npm --version

echo "Node.js installation completed!"