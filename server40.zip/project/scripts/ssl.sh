#!/bin/bash
set -e

source ./config/settings.env

echo "Setting up SSL..."

# Install Certbot
sudo apt-get install -y certbot python3-certbot-nginx

# Get SSL certificate
sudo certbot --nginx \
    --non-interactive \
    --agree-tos \
    --email "${EMAIL}" \
    --domains "${DOMAIN}" \
    --redirect

# Enable auto-renewal
sudo systemctl enable certbot.timer
sudo systemctl start certbot.timer

echo "SSL setup completed!"