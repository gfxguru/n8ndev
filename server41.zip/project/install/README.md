# Ubuntu Server Setup for n8n

This installation script sets up a secure Ubuntu server running n8n with Nginx, Node.js, Redis, and PostgreSQL.

## Features

- Modular installation scripts
- SSL configuration with Let's Encrypt
- Automatic backups
- System monitoring
- Security hardening
- Log rotation
- Fail2ban configuration
- UFW firewall setup

## Prerequisites

- Ubuntu 20.04 or newer
- Root or sudo access
- Domain name pointed to your server

## Installation

1. Update the configuration:
   ```bash
   nano config/settings.env
   ```

2. Make scripts executable:
   ```bash
   chmod +x install.sh scripts/*.sh
   ```

3. Run the installation:
   ```bash
   ./install.sh
   ```

## Post-Installation

1. Change default passwords in settings.env
2. Review firewall rules
3. Check service status:
   ```bash
   systemctl status n8n
   systemctl status nginx
   systemctl status postgresql
   systemctl status redis
   ```

## Backup Location

- Database backups: /opt/backups/database
- Redis backups: /opt/backups/redis
- n8n data backups: /opt/backups/n8n

## Monitoring

- Check logs: /opt/n8n/logs/
- Monitor services: `monit status`
- View system resources: `htop`

## Security

- UFW firewall enabled
- Fail2ban configured
- SSL certificates auto-renewal
- Regular security updates

## Maintenance

- Backups run daily at 2 AM
- Logs are rotated daily
- SSL certificates auto-renew
- System monitoring alerts configured