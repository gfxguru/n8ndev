#!/bin/bash
set -e

source ./scripts/utils/logging.sh

setup_nginx_dirs() {
    log_message "$LOG_INFO" "Creating Nginx directories..."
    mkdir -p /etc/nginx/{conf.d,ssl}
    mkdir -p /var/cache/nginx/{n8n,fastcgi}
    chmod 700 /var/cache/nginx/{n8n,fastcgi}
}

copy_nginx_configs() {
    log_message "$LOG_INFO" "Copying Nginx configurations..."
    cp ./scripts/nginx/conf.d/*.conf /etc/nginx/conf.d/
    chmod 644 /etc/nginx/conf.d/*.conf
}

setup_nginx() {
    log_message "$LOG_INFO" "Setting up Nginx..."
    setup_nginx_dirs
    copy_nginx_configs
    
    if nginx -t; then
        log_message "$LOG_INFO" "Nginx configuration valid"
        systemctl reload nginx
    else
        log_message "$LOG_ERROR" "Invalid Nginx configuration"
        exit 1
    fi
}