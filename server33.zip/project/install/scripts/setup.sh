#!/bin/bash
set -e

source ./utils/validation.sh

# Get and validate configuration
setup_config() {
    while [[ -z "$DOMAIN" ]]; do
        read -p "Enter domain name: " domain
        if validate_domain "$domain"; then
            sed -i "s/DOMAIN=.*/DOMAIN=\"$domain\"/" ./config/settings.env
        fi
    done

    while [[ -z "$EMAIL" ]]; do
        read -p "Enter email address: " email
        if validate_email "$email"; then
            sed -i "s/EMAIL=.*/EMAIL=\"$email\"/" ./config/settings.env
        fi
    done

    # Generate PostgreSQL password if not set
    if [[ -z "$POSTGRES_PASSWORD" ]]; then
        password=$(openssl rand -hex 24)
        sed -i "s/POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=\"$password\"/" ./config/settings.env
    fi
}

setup_config