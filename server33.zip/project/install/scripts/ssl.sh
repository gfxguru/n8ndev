#!/bin/bash
set -e

source ./config/settings.env

setup_ssl() {
    echo "Setting up SSL..."
    
    # Install Certbot
    sudo apt-get install -y certbot python3-certbot-nginx
    
    # Stop Nginx temporarily
    sudo systemctl stop nginx
    
    # Get certificate
    sudo certbot certonly \
        --standalone \
        --non-interactive \
        --agree-tos \
        --email "${EMAIL}" \
        --domains "${DOMAIN}"
    
    # Start Nginx
    sudo systemctl start nginx
    
    # Setup auto-renewal
    sudo systemctl enable certbot.timer
    sudo systemctl start certbot.timer
}

setup_ssl