#!/bin/bash
set -e

# Function to validate domain name (including subdomains)
validate_domain() {
    local domain=$1
    # Allow subdomains with multiple levels (e.g., app.staging.example.com)
    if [[ ! $domain =~ ^([a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$ ]]; then
        echo "Invalid domain name. Please enter a valid domain (e.g., example.com or sub.example.com)"
        return 1
    fi
    return 0
}

# Function to validate email
validate_email() {
    local email=$1
    if [[ ! $email =~ ^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$ ]]; then
        echo "Invalid email address. Please enter a valid email"
        return 1
    fi
    return 0
}

# Function to extract root domain from subdomain
get_root_domain() {
    local domain=$1
    # Extract the last two parts of the domain (e.g., example.com from sub.example.com)
    echo "$domain" | awk -F. '{if (NF>2) {print $(NF-1)"."$NF} else {print $0}}'
}

# Get domain and email
while true; do
    read -p "Enter domain name (e.g., example.com or sub.example.com): " domain
    if validate_domain "$domain"; then
        root_domain=$(get_root_domain "$domain")
        break
    fi
done

while true; do
    read -p "Enter email address for SSL notifications: " email
    if validate_email "$email"; then
        break
    fi
done

# Create settings if they don't exist
if [ ! -f ./config/settings.env ]; then
    cp ./config/settings.env.example ./config/settings.env
fi

# Update settings.env with domain and email
sed -i "s/DOMAIN=.*/DOMAIN=\"$domain\"/" ./config/settings.env
sed -i "s/ROOT_DOMAIN=.*/ROOT_DOMAIN=\"$root_domain\"/" ./config/settings.env
sed -i "s/EMAIL=.*/EMAIL=\"$email\"/" ./config/settings.env

echo "Configuration updated successfully!"