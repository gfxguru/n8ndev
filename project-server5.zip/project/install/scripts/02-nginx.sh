#!/bin/bash
set -e

source ./config/settings.env

setup_nginx() {
    echo "Setting up Nginx..."
    
    # Install Nginx
    sudo apt-get install -y nginx

    # Create cache directories
    sudo mkdir -p /var/cache/nginx/n8n
    sudo chown -R www-data:www-data /var/cache/nginx/n8n
    sudo chmod 700 /var/cache/nginx/n8n

    # Configure Nginx components
    for script in ./scripts/nginx/*.conf; do
        if [ -f "$script" ]; then
            bash "$script"
        fi
    done

    # Configure domain
    bash ./scripts/nginx/nginx-domain.sh

    # Test and restart Nginx
    if sudo nginx -t; then
        sudo systemctl restart nginx
    else
        echo "Nginx configuration test failed!"
        exit 1
    fi
}

setup_nginx